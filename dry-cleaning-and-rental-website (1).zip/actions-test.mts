import "dotenv/config";
import { createRequest, createReview } from "@/actions/public";
import { db } from "@/db";
import { requests, reviews } from "@/db/schema";
import { desc } from "drizzle-orm";

const S = { status: "idle", message: "" } as const;

async function main() {
  // 1. Валидная заявка
  const f1 = new FormData();
  f1.set("fullName", "Тест Тестов");
  f1.set("phone", "+7 (900) 111-22-33");
  f1.set("address", "ул. Тестовая, 1");
  f1.set("comment", "Проверка формы");
  f1.set("service", "Химчистка дивана");
  console.log("valid request:", await createRequest(S, f1));

  // 2. Невалидный телефон
  const f2 = new FormData();
  f2.set("fullName", "Тест");
  f2.set("phone", "123");
  f2.set("address", "ул. Тестовая, 1");
  console.log("bad phone:", await createRequest(S, f2));

  // 3. Honeypot (бот)
  const f3 = new FormData();
  f3.set("fullName", "Bot");
  f3.set("phone", "+79001112233");
  f3.set("address", "ул. Бот");
  f3.set("company", "spammy");
  console.log("honeypot:", await createRequest(S, f3));

  // 4. Отзыв
  const f4 = new FormData();
  f4.set("name", "Проверка Отзывова");
  f4.set("text", "Отличная чистка, всё понравилось!");
  f4.set("rating", "5");
  console.log("review:", await createReview(S, f4));

  const [req, rev] = await Promise.all([
    db.select().from(requests).orderBy(desc(requests.id)).limit(1),
    db.select().from(reviews).orderBy(desc(reviews.id)).limit(1),
  ]);
  console.log("last request row:", req[0].fullName, req[0].status, "|", req[0].serviceTitle);
  console.log("last review row:", rev[0].name, "approved:", rev[0].isApproved);
  process.exit(0);
}
main().catch((e) => { console.error(e); process.exit(1); });
