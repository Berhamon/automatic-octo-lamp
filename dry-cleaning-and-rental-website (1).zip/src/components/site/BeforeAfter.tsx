"use client";

import { ChevronsLeftRight } from "lucide-react";
import { useCallback, useRef, useState } from "react";

/**
 * Интерактивный слайдер «до / после».
 * Тяните за полосу, чтобы сравнить результат.
 */
export function BeforeAfter({
  before,
  after,
  title,
  className = "",
}: {
  before: string;
  after: string;
  title: string;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState(52);
  const dragging = useRef(false);

  const update = useCallback((clientX: number) => {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const p = ((clientX - rect.left) / rect.width) * 100;
    setPos(Math.min(96, Math.max(4, p)));
  }, []);

  const onPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    dragging.current = true;
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    update(e.clientX);
  };

  return (
    <div
      ref={ref}
      onPointerDown={onPointerDown}
      onPointerMove={(e) => dragging.current && update(e.clientX)}
      onPointerUp={() => (dragging.current = false)}
      onPointerCancel={() => (dragging.current = false)}
      className={`group relative select-none overflow-hidden rounded-3xl border border-white/10 bg-moss touch-none cursor-ew-resize ${className}`}
      role="img"
      aria-label={title}
    >
      {/* После — фон */}
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={after}
        alt={`${title} — после`}
        draggable={false}
        className="absolute inset-0 h-full w-full object-cover"
      />
      <span className="absolute right-4 top-4 z-10 rounded-full bg-mint px-3 py-1 text-[11px] font-bold uppercase tracking-widest text-ink">
        После
      </span>

      {/* До — поверх с обрезкой */}
      <div
        className="absolute inset-0 overflow-hidden"
        style={{ width: `${pos}%` }}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={before}
          alt={`${title} — до`}
          draggable={false}
          className="absolute inset-0 h-full w-full object-cover"
          style={{ width: ref.current?.clientWidth ?? "100%" }}
        />
        <span className="absolute left-4 top-4 rounded-full bg-ink/80 px-3 py-1 text-[11px] font-bold uppercase tracking-widest text-cream backdrop-blur">
          До
        </span>
      </div>

      {/* Ползунок */}
      <div
        className="absolute inset-y-0 z-20"
        style={{ left: `${pos}%` }}
        aria-hidden
      >
        <div className="absolute inset-y-0 -translate-x-1/2 w-[3px] bg-white/90 shadow-[0_0_18px_rgba(255,255,255,0.5)]" />
        <div className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2 flex h-11 w-11 items-center justify-center rounded-full bg-mint text-ink shadow-xl transition-transform group-active:scale-90">
          <ChevronsLeftRight size={20} strokeWidth={2.5} />
        </div>
      </div>

      {/* Подзаголовок */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 z-10 bg-gradient-to-t from-ink/85 to-transparent p-5 pt-12">
        <p className="font-display text-sm font-semibold text-cream">{title}</p>
      </div>
    </div>
  );
}
