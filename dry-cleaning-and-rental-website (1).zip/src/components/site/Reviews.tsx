"use client";

import { createReview, type FormState } from "@/actions/public";
import type { Review } from "@/db/schema";
import { motion } from "framer-motion";
import { ChevronLeft, ChevronRight, Loader2, Star, StarHalf } from "lucide-react";
import { useActionState, useRef, useState } from "react";

const initial: FormState = { status: "idle", message: "" };

function Stars({ rating, size = 16 }: { rating: number; size?: number }) {
  return (
    <span className="flex gap-0.5 text-amber-400">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          size={size}
          fill={i < rating ? "currentColor" : "none"}
          className={i < rating ? "" : "text-ink/20"}
          strokeWidth={2}
        />
      ))}
    </span>
  );
}

export function Reviews({ reviews }: { reviews: Review[] }) {
  const trackRef = useRef<HTMLDivElement>(null);
  const [state, action, pending] = useActionState(createReview, initial);
  const [rating, setRating] = useState(5);

  const scroll = (dir: 1 | -1) => {
    trackRef.current?.scrollBy({ left: dir * 380, behavior: "smooth" });
  };

  const avg =
    reviews.length > 0
      ? (reviews.reduce((a, r) => a + r.rating, 0) / reviews.length).toFixed(1)
      : "5.0";

  return (
    <section id="reviews" className="bg-cream py-20 text-ink lg:py-28">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mb-10 flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="mb-3 text-xs font-extrabold uppercase tracking-[0.25em] text-mint-dim">
              Отзывы
            </p>
            <h2 className="font-display text-3xl font-bold leading-tight sm:text-5xl">
              Нам доверяют
              <br />
              <span className="text-ink/40">самое ценное</span>
            </h2>
          </div>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3 rounded-2xl border border-ink/10 bg-white px-5 py-3">
              <span className="font-display text-3xl font-bold">{avg}</span>
              <div>
                <Stars rating={Math.round(Number(avg))} size={15} />
                <p className="mt-0.5 text-xs font-semibold text-ink/50">
                  {reviews.length} отзывов
                </p>
              </div>
            </div>
            {reviews.length > 2 && (
              <div className="hidden gap-2 sm:flex">
                <button
                  onClick={() => scroll(-1)}
                  aria-label="Назад"
                  className="flex h-12 w-12 items-center justify-center rounded-full border border-ink/15 transition hover:bg-ink hover:text-cream"
                >
                  <ChevronLeft size={20} />
                </button>
                <button
                  onClick={() => scroll(1)}
                  aria-label="Вперёд"
                  className="flex h-12 w-12 items-center justify-center rounded-full border border-ink/15 transition hover:bg-ink hover:text-cream"
                >
                  <ChevronRight size={20} />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Карусель */}
      {reviews.length > 0 && (
        <div
          ref={trackRef}
          className="no-scrollbar flex snap-x snap-mandatory gap-5 overflow-x-auto px-5 pb-4 lg:px-[max(1.25rem,calc((100vw-80rem)/2+2rem))]"
        >
          {reviews.map((r, i) => (
            <motion.figure
              key={r.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.55, delay: (i % 4) * 0.07 }}
              className="flex w-[320px] shrink-0 snap-start flex-col rounded-[1.8rem] border border-ink/10 bg-white p-7 shadow-sm sm:w-[380px]"
            >
              <Stars rating={r.rating} />
              <blockquote className="mt-4 flex-1 text-[15px] leading-relaxed text-ink/75">
                «{r.text}»
              </blockquote>
              <figcaption className="mt-6 flex items-center gap-3 border-t border-ink/10 pt-5">
                <span className="flex h-11 w-11 items-center justify-center rounded-full bg-ink font-display text-sm font-bold text-mint">
                  {r.name.slice(0, 1).toUpperCase()}
                </span>
                <div>
                  <p className="text-sm font-bold">{r.name}</p>
                  <p className="text-xs text-ink/45">
                    {new Date(r.createdAt).toLocaleDateString("ru-RU")}
                  </p>
                </div>
              </figcaption>
            </motion.figure>
          ))}
        </div>
      )}

      {/* Форма отзыва */}
      <div className="mx-auto mt-10 max-w-7xl px-5 lg:px-8">
        <div className="rounded-[2rem] border border-ink/10 bg-white p-7 sm:p-10">
          <div className="flex items-center gap-3">
            <StarHalf className="text-mint-dim" size={22} />
            <h3 className="font-display text-xl font-bold">Оставить отзыв</h3>
          </div>

          {state.status === "success" ? (
            <p className="mt-6 rounded-2xl border border-emerald-300 bg-emerald-50 px-6 py-5 font-semibold text-emerald-800">
              {state.message}
            </p>
          ) : (
            <form
              action={action}
              className="mt-6 grid gap-4 lg:grid-cols-[220px_1fr_auto]"
            >
              <input
                type="text"
                name="company"
                tabIndex={-1}
                autoComplete="off"
                className="hidden"
                aria-hidden="true"
              />
              <input type="hidden" name="rating" value={rating} />
              <div className="space-y-3">
                <input
                  name="name"
                  required
                  placeholder="Ваше имя *"
                  className="w-full rounded-2xl border border-ink/15 bg-cream/60 px-5 py-3.5 outline-none transition focus:border-mint-dim"
                />
                <div className="flex items-center gap-1.5 px-1">
                  <span className="mr-1 text-sm font-semibold text-ink/50">
                    Оценка:
                  </span>
                  {Array.from({ length: 5 }).map((_, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setRating(i + 1)}
                      aria-label={`Оценка ${i + 1}`}
                      className="transition hover:scale-125"
                    >
                      <Star
                        size={24}
                        className={
                          i < rating
                            ? "fill-amber-400 text-amber-400"
                            : "text-ink/20"
                        }
                      />
                    </button>
                  ))}
                </div>
              </div>
              <textarea
                name="text"
                required
                rows={3}
                placeholder="Расскажите, как прошла чистка — что понравилось, что улучшить... *"
                className="resize-none rounded-2xl border border-ink/15 bg-cream/60 px-5 py-3.5 outline-none transition focus:border-mint-dim lg:min-h-[96px]"
              />
              <div className="flex flex-col justify-end">
                {state.status === "error" && (
                  <p className="mb-2 text-sm font-semibold text-red-600">
                    {state.message}
                  </p>
                )}
                <button
                  type="submit"
                  disabled={pending}
                  className="flex h-[52px] items-center justify-center gap-2 whitespace-nowrap rounded-full bg-ink px-8 font-bold text-cream transition hover:bg-mint hover:text-ink disabled:opacity-60"
                >
                  {pending && <Loader2 size={18} className="animate-spin" />}
                  Отправить
                </button>
              </div>
            </form>
          )}
          <p className="mt-4 text-xs text-ink/40">
            Отзыв будет опубликован после проверки модератором
          </p>
        </div>
      </div>
    </section>
  );
}
