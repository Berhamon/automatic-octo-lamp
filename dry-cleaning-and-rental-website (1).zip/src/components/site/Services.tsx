"use client";

import type { Service } from "@/db/schema";
import { linesToList } from "@/lib/format";
import { motion } from "framer-motion";
import { ArrowRight, Check, KeyRound, Sparkles } from "lucide-react";
import { useState } from "react";

export function Services({ services }: { services: Service[] }) {
  const [tab, setTab] = useState<"service" | "rental">("service");
  const filtered = services.filter((s) => s.category === tab);

  const order = (title: string) => {
    window.dispatchEvent(
      new CustomEvent("service-selected", { detail: title })
    );
    document.getElementById("request")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="services" className="bg-cream py-20 text-ink lg:py-28">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mb-12 flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="mb-3 text-xs font-extrabold uppercase tracking-[0.25em] text-mint-dim">
              Каталог
            </p>
            <h2 className="font-display text-3xl font-bold leading-tight tracking-tight sm:text-5xl">
              Услуги и аренда
              <br />
              <span className="text-ink/40">в одном месте</span>
            </h2>
          </div>

          {/* Переключатель */}
          <div className="flex w-fit rounded-full border border-ink/10 bg-white p-1.5 shadow-sm">
            {(
              [
                { key: "service", label: "Услуги химчистки", Icon: Sparkles },
                { key: "rental", label: "Аренда оборудования", Icon: KeyRound },
              ] as const
            ).map(({ key, label, Icon }) => (
              <button
                key={key}
                onClick={() => setTab(key)}
                className={`flex items-center gap-2 rounded-full px-5 py-3 text-sm font-bold transition-all sm:px-6 ${
                  tab === key
                    ? "bg-ink text-cream shadow-lg"
                    : "text-ink/50 hover:text-ink"
                }`}
              >
                <Icon size={16} />
                {label}
              </button>
            ))}
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="rounded-3xl border border-dashed border-ink/20 p-14 text-center text-ink/50">
            Карточки скоро появятся
          </div>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((s, i) => (
              <motion.article
                key={s.id}
                initial={{ opacity: 0, y: 36 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.6, delay: (i % 3) * 0.08 }}
                className="group flex flex-col overflow-hidden rounded-[2rem] border border-ink/10 bg-white shadow-[0_2px_20px_rgba(7,18,15,0.05)] transition-all duration-300 hover:-translate-y-2 hover:shadow-[0_24px_50px_-20px_rgba(7,18,15,0.25)]"
              >
                <div className="relative h-48 overflow-hidden bg-pine">
                  {s.imageUrl ? (
                    /* eslint-disable-next-line @next/next/no-img-element */
                    <img
                      src={s.imageUrl}
                      alt={s.title}
                      className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-pine to-moss">
                      {s.category === "rental" ? (
                        <KeyRound size={48} className="text-mint/40" />
                      ) : (
                        <Sparkles size={48} className="text-mint/40" />
                      )}
                    </div>
                  )}
                  {s.price && (
                    <span className="absolute bottom-4 left-4 rounded-full bg-mint px-4 py-1.5 font-display text-sm font-bold text-ink shadow-lg">
                      {s.price}
                    </span>
                  )}
                </div>

                <div className="flex flex-1 flex-col p-6">
                  <h3 className="font-display text-lg font-bold leading-snug">
                    {s.title}
                  </h3>
                  {s.description && (
                    <p className="mt-2 text-sm leading-relaxed text-ink/60">
                      {s.description}
                    </p>
                  )}
                  {linesToList(s.features).length > 0 && (
                    <ul className="mt-4 space-y-2">
                      {linesToList(s.features).map((f, j) => (
                        <li
                          key={j}
                          className="flex items-start gap-2 text-sm text-ink/75"
                        >
                          <Check
                            size={16}
                            className="mt-0.5 shrink-0 text-mint-dim"
                            strokeWidth={3}
                          />
                          {f}
                        </li>
                      ))}
                    </ul>
                  )}
                  <button
                    onClick={() => order(s.title)}
                    className="mt-6 flex w-full items-center justify-center gap-2 rounded-full bg-ink py-3.5 text-sm font-bold text-cream transition hover:bg-mint hover:text-ink"
                  >
                    {s.category === "rental" ? "Арендовать" : "Заказать"}
                    <ArrowRight size={16} />
                  </button>
                </div>
              </motion.article>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
