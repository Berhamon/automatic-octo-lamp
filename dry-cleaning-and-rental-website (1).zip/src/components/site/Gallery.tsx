import type { GalleryItem } from "@/db/schema";
import { BeforeAfter } from "./BeforeAfter";
import { Reveal } from "./Reveal";
import { MoveHorizontal } from "lucide-react";

export function Gallery({ items }: { items: GalleryItem[] }) {
  if (items.length === 0) return null;
  const [first, ...rest] = items;

  return (
    <section id="works" className="grain relative py-20 lg:py-28">
      <div className="pointer-events-none absolute left-1/2 top-0 h-[400px] w-[600px] -translate-x-1/2 rounded-full bg-mint/5 blur-3xl" />
      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <Reveal className="mb-12 flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="mb-3 text-xs font-extrabold uppercase tracking-[0.25em] text-mint">
              Галерея
            </p>
            <h2 className="font-display text-3xl font-bold leading-tight sm:text-5xl">
              Наши работы
              <br />
              <span className="text-cream/40">до и после</span>
            </h2>
          </div>
          <p className="flex items-center gap-3 rounded-full border border-white/15 px-6 py-3 text-sm font-bold text-cream/70">
            <MoveHorizontal size={18} className="text-mint" />
            Тяните ползунок на фото
          </p>
        </Reveal>

        <div className="grid gap-6 lg:grid-cols-2">
          <Reveal>
            <BeforeAfter
              before={first.beforeUrl}
              after={first.afterUrl}
              title={first.title}
              className="aspect-[4/3]"
            />
            {first.description && (
              <p className="mt-4 text-sm text-cream/55">{first.description}</p>
            )}
          </Reveal>
          <div className="grid gap-6 sm:grid-cols-2">
            {rest.slice(0, 4).map((item, i) => (
              <Reveal key={item.id} delay={i * 0.08}>
                <BeforeAfter
                  before={item.beforeUrl}
                  after={item.afterUrl}
                  title={item.title}
                  className="aspect-square"
                />
              </Reveal>
            ))}
          </div>
        </div>

        {rest.length > 4 && (
          <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {rest.slice(4).map((item, i) => (
              <Reveal key={item.id} delay={i * 0.08}>
                <BeforeAfter
                  before={item.beforeUrl}
                  after={item.afterUrl}
                  title={item.title}
                  className="aspect-[4/3]"
                />
              </Reveal>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
