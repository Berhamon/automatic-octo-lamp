import type { AboutInfo } from "@/db/schema";
import { Reveal } from "./Reveal";
import { BadgeCheck, Medal, Phone, ShieldCheck } from "lucide-react";

export function About({ about }: { about: AboutInfo | null }) {
  if (!about) return null;
  const tel = about.phone.replace(/[^\d+]/g, "");

  return (
    <section id="about" className="border-t border-ink/10 bg-cream py-20 text-ink lg:py-28">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 lg:grid-cols-[0.85fr_1.15fr] lg:gap-20 lg:px-8">
        <Reveal className="relative">
          <div className="absolute -inset-4 -rotate-2 rounded-[3rem] bg-mint/25" />
          <div className="relative overflow-hidden rounded-[2.8rem] border-4 border-white shadow-2xl">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={about.photoUrl || "/img/about.jpg"}
              alt={about.fullName}
              className="aspect-[4/5] w-full object-cover"
            />
          </div>
          {about.yearsExperience > 0 && (
            <div className="absolute -bottom-6 -right-3 rotate-3 rounded-3xl bg-ink px-7 py-5 text-cream shadow-2xl sm:right-8">
              <p className="font-display text-3xl font-bold text-mint">
                {about.yearsExperience} лет
              </p>
              <p className="text-xs font-bold uppercase tracking-widest text-cream/60">
                в профессиональной чистке
              </p>
            </div>
          )}
        </Reveal>

        <div>
          <Reveal>
            <p className="mb-3 text-xs font-extrabold uppercase tracking-[0.25em] text-mint-dim">
              О мастере
            </p>
            <h2 className="font-display text-3xl font-bold leading-tight sm:text-5xl">
              {about.fullName}
            </h2>
            {about.role && (
              <p className="mt-3 text-lg font-semibold text-ink/50">
                {about.role}
              </p>
            )}
            <p className="mt-6 whitespace-pre-line text-[17px] leading-relaxed text-ink/70">
              {about.description}
            </p>
          </Reveal>

          <Reveal delay={0.15} className="mt-8 grid gap-4 sm:grid-cols-3">
            {[
              { icon: Medal, text: "Сертифицированный мастер чистки" },
              { icon: ShieldCheck, text: "Гарантия и страховка имущества" },
              { icon: BadgeCheck, text: "Только профессиональная химия" },
            ].map((g) => (
              <div
                key={g.text}
                className="rounded-2xl border border-ink/10 bg-white p-5"
              >
                <g.icon size={22} className="text-mint-dim" />
                <p className="mt-3 text-sm font-semibold leading-snug text-ink/75">
                  {g.text}
                </p>
              </div>
            ))}
          </Reveal>

          {about.phone && (
            <Reveal delay={0.25} className="mt-8">
              <a
                href={`tel:${tel}`}
                className="inline-flex items-center gap-4 rounded-full bg-ink py-3 pl-4 pr-8 text-cream transition hover:scale-[1.02]"
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-full bg-mint text-ink">
                  <Phone size={19} />
                </span>
                <span>
                  <span className="block text-xs font-semibold uppercase tracking-widest text-cream/55">
                    Прямая связь с мастером
                  </span>
                  <span className="font-display text-lg font-bold">
                    {about.phone}
                  </span>
                </span>
              </a>
            </Reveal>
          )}
        </div>
      </div>
    </section>
  );
}
