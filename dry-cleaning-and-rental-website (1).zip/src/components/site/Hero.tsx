"use client";

import { motion } from "framer-motion";
import { ArrowDown, BadgeCheck, ShieldCheck, Timer } from "lucide-react";

const STATS = [
  { value: "500+", label: "выполненных заказов" },
  { value: "7 лет", label: "опыта в химчистке" },
  { value: "1200 м²", label: "отчищено ковров" },
  { value: "100%", label: "гарантия результата" },
];

export function Hero({ phone }: { phone: string }) {
  const tel = phone.replace(/[^\d+]/g, "");
  return (
    <section id="top" className="grain relative overflow-hidden pt-[72px]">
      {/* свечения */}
      <div className="glow-mint pointer-events-none absolute -top-40 right-[-10%] h-[560px] w-[560px] rounded-full" />
      <div className="pointer-events-none absolute -left-40 top-1/3 h-[420px] w-[420px] rounded-full bg-mint/5 blur-3xl" />

      <div className="relative mx-auto grid max-w-7xl gap-12 px-5 pb-16 pt-10 lg:grid-cols-[1.1fr_0.9fr] lg:items-center lg:px-8 lg:pb-24 lg:pt-16">
        <div>
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-6 flex flex-wrap items-center gap-3"
          >
            <span className="flex items-center gap-2 rounded-full border border-mint/30 bg-mint/10 px-4 py-2 text-xs font-bold uppercase tracking-[0.18em] text-mint">
              <span className="dot-live h-2 w-2 rounded-full bg-mint" />
              Работаем с выездом на дом
            </span>
          </motion.div>

          <h1 className="font-display text-[clamp(2rem,5.4vw,4.4rem)] font-extrabold leading-[1.04] tracking-tight">
            <motion.span
              className="block"
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.08 }}
            >
              Химчистка мебели
            </motion.span>
            <motion.span
              className="block text-mint"
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
            >
              и аренда
            </motion.span>
            <motion.span
              className="text-stroke block"
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.32 }}
            >
              оборудования
            </motion.span>
          </h1>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.42 }}
            className="mt-6 max-w-xl text-lg leading-relaxed text-cream/70"
          >
            Вернём дивану, ковру и матрасу первозданный вид за 2–4 часа.
            Профессиональная химия и экстракторная чистка. Или возьмите
            оборудование в аренду и сделайте всё сами — подскажем как.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.52 }}
            className="mt-9 flex flex-wrap items-center gap-4"
          >
            <a
              href="#request"
              className="group flex items-center gap-3 rounded-full bg-mint px-8 py-4 font-display text-sm font-bold text-ink shadow-[0_10px_40px_-10px_rgba(62,240,165,0.6)] transition hover:scale-[1.03] hover:brightness-105 active:scale-95"
            >
              Оставить заявку
              <ArrowDown
                size={18}
                className="transition-transform group-hover:translate-y-0.5"
              />
            </a>
            {phone && (
              <a
                href={`tel:${tel}`}
                className="rounded-full border border-white/20 px-8 py-4 text-sm font-bold text-cream transition hover:border-mint hover:text-mint"
              >
                {phone}
              </a>
            )}
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.7 }}
            className="mt-10 flex flex-wrap gap-x-8 gap-y-3 text-sm text-cream/60"
          >
            <span className="flex items-center gap-2">
              <Timer size={16} className="text-mint" /> Приезд в день обращения
            </span>
            <span className="flex items-center gap-2">
              <ShieldCheck size={16} className="text-mint" /> Безопасная химия
            </span>
            <span className="flex items-center gap-2">
              <BadgeCheck size={16} className="text-mint" /> Договор и чек
            </span>
          </motion.div>
        </div>

        {/* Фото */}
        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 30 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.3, ease: [0.21, 0.65, 0.25, 1] }}
          className="relative"
        >
          <div className="relative overflow-hidden rounded-[2.5rem] border border-white/10 shadow-2xl">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src="/img/hero.jpg"
              alt="Профессиональная химчистка дивана"
              className="aspect-[4/5] w-full object-cover lg:aspect-[3/4]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-ink/60 via-transparent to-transparent" />
          </div>

          <div className="animate-float absolute -left-4 top-8 rounded-3xl border border-white/10 bg-pine/90 p-5 shadow-2xl backdrop-blur lg:-left-10">
            <p className="font-display text-3xl font-bold text-mint">500+</p>
            <p className="mt-1 text-xs font-semibold uppercase tracking-widest text-cream/60">
              довольных клиентов
            </p>
          </div>

          <div
            className="animate-float absolute -bottom-6 right-4 rounded-3xl border border-white/10 bg-mint p-5 text-ink shadow-2xl lg:right-10"
            style={{ animationDelay: "1.4s" }}
          >
            <p className="font-display text-2xl font-bold">от 1 500 ₽</p>
            <p className="text-xs font-bold uppercase tracking-widest opacity-70">
              чистка стула
            </p>
          </div>
        </motion.div>
      </div>

      {/* Статистика */}
      <div className="relative border-t border-white/10">
        <div className="mx-auto grid max-w-7xl grid-cols-2 divide-x divide-white/10 px-5 lg:grid-cols-4 lg:px-8">
          {STATS.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
              className="px-4 py-8 lg:px-8"
            >
              <p className="font-display text-2xl font-bold text-cream lg:text-3xl">
                {s.value}
              </p>
              <p className="mt-1 text-xs font-semibold uppercase tracking-widest text-cream/50">
                {s.label}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
