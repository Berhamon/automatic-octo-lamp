import { Reveal } from "./Reveal";
import { CalendarCheck, Droplets, PhoneCall, Sparkles } from "lucide-react";

const STEPS = [
  {
    icon: PhoneCall,
    title: "Заявка или звонок",
    text: "Оставляете заявку на сайте — перезваниваем, уточняем детали и называем точную цену.",
  },
  {
    icon: CalendarCheck,
    title: "Приезд в слот",
    text: "Мастер приезжает в удобное окно времени с полным комплектом оборудования и химии.",
  },
  {
    icon: Droplets,
    title: "Глубокая чистка",
    text: "Предварительная обработка пятен, экстракторная чистка, антибактериальная защита.",
  },
  {
    icon: Sparkles,
    title: "Принимаете работу",
    text: "Показываем результат, вы оплачиваете после приёмки. Мебель высыхает за 6–10 часов.",
  },
];

export function Steps() {
  return (
    <section className="border-t border-ink/10 bg-sand py-20 text-ink lg:py-24">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <Reveal className="mb-12">
          <p className="mb-3 text-xs font-extrabold uppercase tracking-[0.25em] text-mint-dim">
            Процесс
          </p>
          <h2 className="font-display text-3xl font-bold sm:text-5xl">
            Как мы <span className="text-ink/40">работаем</span>
          </h2>
        </Reveal>

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {STEPS.map((s, i) => (
            <Reveal key={s.title} delay={i * 0.1}>
              <div className="group relative h-full overflow-hidden rounded-[1.8rem] border border-ink/10 bg-white p-7 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-xl">
                <span className="absolute -right-2 -top-5 font-display text-[92px] font-extrabold leading-none text-ink/[0.05] transition group-hover:text-mint-dim/15">
                  0{i + 1}
                </span>
                <span className="relative flex h-13 w-13 items-center justify-center rounded-2xl bg-ink text-mint transition group-hover:bg-mint group-hover:text-ink">
                  <s.icon size={24} />
                </span>
                <h3 className="relative mt-5 font-display text-base font-bold">
                  {s.title}
                </h3>
                <p className="relative mt-2 text-sm leading-relaxed text-ink/60">
                  {s.text}
                </p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
