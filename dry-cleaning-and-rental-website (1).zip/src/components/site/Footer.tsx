import {
  Clock,
  Lock,
  Mail,
  MapPin,
  MessageCircle,
  Phone,
  Send,
  Sparkles,
} from "lucide-react";

export function Footer({
  settings,
}: {
  settings: Record<string, string>;
}) {
  const phone = settings.phone ?? "";
  const tel = phone.replace(/[^\d+]/g, "");

  return (
    <footer className="grain relative border-t border-white/10 bg-ink">
      <div className="mx-auto max-w-7xl px-5 py-14 lg:px-8">
        <div className="grid gap-10 md:grid-cols-[1.3fr_1fr_1fr]">
          <div>
            <a href="#top" className="flex items-center gap-2.5">
              <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-mint text-ink">
                <Sparkles size={20} strokeWidth={2.5} />
              </span>
              <span className="font-display text-lg font-bold">
                Проф<span className="text-mint">Чистка</span>
              </span>
            </a>
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-cream/55">
              Профессиональная химчистка мебели, ковров и салонов автомобилей.
              Аренда оборудования для самостоятельной чистки.
            </p>
          </div>

          <div>
            <p className="text-xs font-extrabold uppercase tracking-[0.25em] text-cream/40">
              Контакты
            </p>
            <ul className="mt-5 space-y-3 text-sm">
              {phone && (
                <li>
                  <a
                    href={`tel:${tel}`}
                    className="flex items-center gap-3 font-semibold text-cream/80 transition hover:text-mint"
                  >
                    <Phone size={16} className="text-mint" /> {phone}
                  </a>
                </li>
              )}
              {settings.email && (
                <li>
                  <a
                    href={`mailto:${settings.email}`}
                    className="flex items-center gap-3 text-cream/80 transition hover:text-mint"
                  >
                    <Mail size={16} className="text-mint" /> {settings.email}
                  </a>
                </li>
              )}
              {settings.city && (
                <li className="flex items-center gap-3 text-cream/80">
                  <MapPin size={16} className="text-mint" /> {settings.city}
                </li>
              )}
              {settings.workingHours && (
                <li className="flex items-center gap-3 text-cream/80">
                  <Clock size={16} className="text-mint" /> {settings.workingHours}
                </li>
              )}
            </ul>
          </div>

          <div>
            <p className="text-xs font-extrabold uppercase tracking-[0.25em] text-cream/40">
              Мы на связи
            </p>
            <div className="mt-5 flex gap-3">
              {settings.whatsapp && (
                <a
                  href={settings.whatsapp}
                  target="_blank"
                  rel="noreferrer"
                  aria-label="WhatsApp"
                  className="flex h-12 w-12 items-center justify-center rounded-full border border-white/15 text-cream/70 transition hover:border-mint hover:bg-mint hover:text-ink"
                >
                  <MessageCircle size={20} />
                </a>
              )}
              {settings.telegram && (
                <a
                  href={settings.telegram}
                  target="_blank"
                  rel="noreferrer"
                  aria-label="Telegram"
                  className="flex h-12 w-12 items-center justify-center rounded-full border border-white/15 text-cream/70 transition hover:border-mint hover:bg-mint hover:text-ink"
                >
                  <Send size={20} />
                </a>
              )}
            </div>
            <a
              href="#request"
              className="mt-6 inline-block rounded-full bg-mint px-7 py-3 text-sm font-bold text-ink transition hover:brightness-110"
            >
              Оставить заявку
            </a>
          </div>
        </div>

        <div className="mt-12 flex flex-wrap items-center justify-between gap-4 border-t border-white/10 pt-7 text-xs text-cream/40">
          <p>© {new Date().getFullYear()} ПрофЧистка. Все права защищены.</p>
          <a
            href="/admin"
            className="flex items-center gap-2 transition hover:text-mint"
          >
            <Lock size={13} /> Вход для администратора
          </a>
        </div>
      </div>
    </footer>
  );
}
