import { Reveal } from "./Reveal";
import { Plus } from "lucide-react";

const FAQ = [
  {
    q: "Сколько сохнет мебель после чистки?",
    a: "В среднем 6–10 часов при комнатной температуре. Турбосушкой можно ускорить процесс до 2–4 часов. Зимой при открытом проветривании сохнет быстрее.",
  },
  {
    q: "Химия безопасна для детей и животных?",
    a: "Да, работаем сертифицированными средствами европейских брендов — гипоаллергенными и биоразлагаемыми. После высыхания следов химии не остаётся.",
  },
  {
    q: "Как рассчитывается стоимость аренды оборудования?",
    a: "Аренда считается посуточно. В стоимость входит аппарат, насадки и инструкция. Химию можно докупить отдельно. Для получения нужен паспорт и залог.",
  },
  {
    q: "Что если пятно не отойдёт?",
    a: "Перед началом мастер честно оценит перспективы. Если результат хуже обещанного — сделаем скидку 20%. Старинные пятна от краски и плесени отводим отдельно.",
  },
  {
    q: "Нужно ли что-то подготовить к приезду мастера?",
    a: "Нет. Мастер приносит всё с собой: оборудование, химию, бахилы. Нужен только доступ к розетке и воде. Мебель при желании отодвинем и вернём на место.",
  },
];

export function Faq() {
  return (
    <section id="faq" className="border-t border-ink/10 bg-sand py-20 text-ink lg:py-28">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 lg:grid-cols-[0.8fr_1.2fr] lg:px-8">
        <Reveal>
          <p className="mb-3 text-xs font-extrabold uppercase tracking-[0.25em] text-mint-dim">
            FAQ
          </p>
          <h2 className="font-display text-3xl font-bold leading-tight sm:text-5xl">
            Частые
            <br />
            <span className="text-ink/40">вопросы</span>
          </h2>
          <p className="mt-5 max-w-sm text-ink/60">
            Не нашли ответ — позвоните или оставьте заявку, мастер проконсультирует
            бесплатно.
          </p>
        </Reveal>

        <div className="space-y-3">
          {FAQ.map((f, i) => (
            <Reveal key={i} delay={i * 0.05}>
              <details className="faq group rounded-3xl border border-ink/10 bg-white transition open:border-mint-dim/40">
                <summary className="flex cursor-pointer list-none items-center justify-between gap-4 px-7 py-5 font-display text-[15px] font-bold transition">
                  {f.q}
                  <span className="faq-chevron flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-ink/15 transition group-open:border-mint-dim group-open:bg-mint group-open:text-ink">
                    <Plus size={17} />
                  </span>
                </summary>
                <p className="px-7 pb-6 text-[15px] leading-relaxed text-ink/65">
                  {f.a}
                </p>
              </details>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
