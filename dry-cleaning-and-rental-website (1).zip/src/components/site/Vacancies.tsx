import type { VacancyLink } from "@/db/schema";
import { Reveal } from "./Reveal";
import { ArrowUpRight, BriefcaseBusiness } from "lucide-react";

export function Vacancies({ vacancies }: { vacancies: VacancyLink[] }) {
  if (vacancies.length === 0) return null;

  return (
    <section id="vacancies" className="grain relative py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <Reveal className="mb-12">
          <p className="mb-3 flex items-center gap-2 text-xs font-extrabold uppercase tracking-[0.25em] text-mint">
            <BriefcaseBusiness size={16} /> Работа у нас
          </p>
          <h2 className="font-display text-3xl font-bold leading-tight sm:text-5xl">
            Открытые <span className="text-cream/40">вакансии</span>
          </h2>
          <p className="mt-4 max-w-xl text-cream/60">
            Мы растём и ищем мастеров и помощников. Актуальные вакансии также
            публикуем на популярных площадках — переходите и откликайтесь.
          </p>
        </Reveal>

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {vacancies.map((v, i) => (
            <Reveal key={v.id} delay={i * 0.07}>
              <a
                href={v.url}
                target="_blank"
                rel="noreferrer"
                className="group flex h-full flex-col rounded-[1.8rem] border border-white/10 bg-pine/60 p-7 backdrop-blur transition-all duration-300 hover:-translate-y-1.5 hover:border-mint/40 hover:bg-pine"
              >
                <div className="flex items-start justify-between gap-4">
                  {v.source && (
                    <span className="rounded-full bg-mint/15 px-4 py-1.5 text-xs font-extrabold uppercase tracking-widest text-mint">
                      {v.source}
                    </span>
                  )}
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-white/15 text-cream/60 transition group-hover:border-mint group-hover:bg-mint group-hover:text-ink">
                    <ArrowUpRight size={18} />
                  </span>
                </div>
                <h3 className="mt-5 font-display text-lg font-bold leading-snug">
                  {v.title}
                </h3>
                {v.description && (
                  <p className="mt-3 flex-1 text-sm leading-relaxed text-cream/55">
                    {v.description}
                  </p>
                )}
                <p className="mt-5 text-sm font-bold text-mint">
                  Открыть вакансию →
                </p>
              </a>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
