const ITEMS = [
  "Химчистка диванов",
  "Чистка ковров",
  "Аренда оборудования",
  "Матрасы",
  "Автокресла",
  "Офисная мебель",
  "Выезд на дом",
  "Эко-средства",
];

export function Marquee() {
  const row = [...ITEMS, ...ITEMS];
  return (
    <div className="relative overflow-hidden border-y border-white/10 bg-pine py-5">
      <div className="flex w-max animate-marquee items-center gap-8 pr-8">
        {row.map((item, i) => (
          <span
            key={i}
            className="flex items-center gap-8 font-display text-sm font-semibold uppercase tracking-[0.2em] text-cream/60"
          >
            {item}
            <span className="h-2 w-2 rounded-full bg-mint" aria-hidden />
          </span>
        ))}
      </div>
    </div>
  );
}
