"use client";

import { MessageCircle, Phone, Send, X } from "lucide-react";
import { useState } from "react";

/** Плавающая кнопка быстрой связи. */
export function FloatingContact({
  phone,
  whatsapp,
  telegram,
}: {
  phone: string;
  whatsapp: string;
  telegram: string;
}) {
  const [open, setOpen] = useState(false);
  const tel = phone.replace(/[^\d+]/g, "");

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3">
      {open && (
        <div className="flex flex-col gap-2 rounded-3xl border border-white/10 bg-pine/95 p-3 shadow-2xl backdrop-blur">
          {phone && (
            <a
              href={`tel:${tel}`}
              className="flex items-center gap-3 rounded-2xl bg-mint px-4 py-3 text-sm font-bold text-ink transition hover:brightness-110"
            >
              <Phone size={18} /> {phone}
            </a>
          )}
          {whatsapp && (
            <a
              href={whatsapp}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-3 rounded-2xl bg-white/10 px-4 py-3 text-sm font-semibold text-cream transition hover:bg-white/20"
            >
              <MessageCircle size={18} className="text-mint" /> WhatsApp
            </a>
          )}
          {telegram && (
            <a
              href={telegram}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-3 rounded-2xl bg-white/10 px-4 py-3 text-sm font-semibold text-cream transition hover:bg-white/20"
            >
              <Send size={18} className="text-mint" /> Telegram
            </a>
          )}
        </div>
      )}
      <button
        onClick={() => setOpen((v) => !v)}
        aria-label="Связаться с нами"
        className="dot-live flex h-16 w-16 items-center justify-center rounded-full bg-mint text-ink shadow-2xl transition hover:scale-105 active:scale-95"
      >
        {open ? <X size={26} /> : <Phone size={26} />}
      </button>
    </div>
  );
}
