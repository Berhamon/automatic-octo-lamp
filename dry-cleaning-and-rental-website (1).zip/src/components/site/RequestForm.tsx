"use client";

import { createRequest, type FormState } from "@/actions/public";
import { motion } from "framer-motion";
import {
  CheckCircle2,
  ClipboardList,
  Loader2,
  MapPin,
  MessageSquareText,
  Phone,
  Sparkles,
  User,
} from "lucide-react";
import { useActionState, useEffect, useState } from "react";

const initial: FormState = { status: "idle", message: "" };

const inputCls =
  "w-full rounded-2xl border border-white/15 bg-white/5 px-5 py-4 text-cream placeholder:text-cream/35 outline-none transition focus:border-mint focus:bg-white/10";

export function RequestForm({ services }: { services: string[] }) {
  const [state, action, pending] = useActionState(createRequest, initial);
  const [service, setService] = useState("");

  useEffect(() => {
    const handler = (e: Event) =>
      setService((e as CustomEvent<string>).detail ?? "");
    window.addEventListener("service-selected", handler);
    return () => window.removeEventListener("service-selected", handler);
  }, []);

  return (
    <section id="request" className="grain relative overflow-hidden py-20 lg:py-28">
      <div className="glow-mint pointer-events-none absolute -bottom-40 left-1/2 h-[500px] w-[700px] -translate-x-1/2 rounded-full" />
      <div className="relative mx-auto grid max-w-7xl gap-12 px-5 lg:grid-cols-[0.9fr_1.1fr] lg:items-center lg:px-8">
        <div>
          <p className="mb-3 text-xs font-extrabold uppercase tracking-[0.25em] text-mint">
            Заявка
          </p>
          <h2 className="font-display text-3xl font-bold leading-tight sm:text-5xl">
            Оставьте заявку —<br />
            <span className="text-mint">перезвоним</span> за 15 минут
          </h2>
          <p className="mt-5 max-w-md text-cream/65">
            Укажите контакты и адрес — уточним детали, назовём точную цену и
            приедем в удобное время. Работаем ежедневно с 8:00 до 22:00.
          </p>
          <ul className="mt-8 space-y-4">
            {[
              "Выезд и оценка — бесплатно",
              "Фиксированная цена до начала работ",
              "Если пятно не отходит — скидка 20%",
            ].map((t) => (
              <li key={t} className="flex items-center gap-3 text-cream/80">
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-mint/15 text-mint">
                  <CheckCircle2 size={17} />
                </span>
                {t}
              </li>
            ))}
          </ul>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 36 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="rounded-[2rem] border border-white/10 bg-pine/70 p-6 shadow-2xl backdrop-blur sm:p-9"
        >
          {state.status === "success" ? (
            <div className="flex flex-col items-center py-14 text-center">
              <span className="flex h-20 w-20 items-center justify-center rounded-full bg-mint/15 text-mint">
                <CheckCircle2 size={44} />
              </span>
              <h3 className="mt-6 font-display text-2xl font-bold">
                Заявка принята!
              </h3>
              <p className="mt-3 max-w-sm text-cream/65">{state.message}</p>
              <button
                onClick={() => window.location.reload()}
                className="mt-8 rounded-full border border-white/20 px-7 py-3 text-sm font-bold text-cream transition hover:border-mint hover:text-mint"
              >
                Отправить ещё одну
              </button>
            </div>
          ) : (
            <form action={action} className="space-y-4">
              {/* honeypot */}
              <input
                type="text"
                name="company"
                tabIndex={-1}
                autoComplete="off"
                className="hidden"
                aria-hidden="true"
              />

              <div className="relative">
                <User
                  size={18}
                  className="absolute left-5 top-1/2 -translate-y-1/2 text-mint/70"
                />
                <input
                  name="fullName"
                  required
                  placeholder="ФИО *"
                  className={`${inputCls} pl-12`}
                />
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="relative">
                  <Phone
                    size={18}
                    className="absolute left-5 top-1/2 -translate-y-1/2 text-mint/70"
                  />
                  <input
                    name="phone"
                    required
                    type="tel"
                    placeholder="Телефон *"
                    className={`${inputCls} pl-12`}
                  />
                </div>
                <div className="relative">
                  <MapPin
                    size={18}
                    className="absolute left-5 top-1/2 -translate-y-1/2 text-mint/70"
                  />
                  <input
                    name="address"
                    required
                    placeholder="Адрес *"
                    className={`${inputCls} pl-12`}
                  />
                </div>
              </div>

              <div className="relative">
                <ClipboardList
                  size={18}
                  className="absolute left-5 top-5 text-mint/70"
                />
                <select
                  name="service"
                  value={service}
                  onChange={(e) => setService(e.target.value)}
                  className={`${inputCls} appearance-none pl-12 ${service ? "" : "text-cream/35"}`}
                >
                  <option value="" className="bg-pine text-cream/60">
                    Что нужно почистить / арендовать?
                  </option>
                  {services.map((s) => (
                    <option key={s} value={s} className="bg-pine text-cream">
                      {s}
                    </option>
                  ))}
                  <option value="Другое" className="bg-pine text-cream">
                    Другое
                  </option>
                </select>
              </div>

              <div className="relative">
                <MessageSquareText
                  size={18}
                  className="absolute left-5 top-5 text-mint/70"
                />
                <textarea
                  name="comment"
                  rows={3}
                  placeholder="Комментарий: описание пятен, удобное время, пожелания..."
                  className={`${inputCls} resize-none pl-12`}
                />
              </div>

              {state.status === "error" && (
                <p className="rounded-2xl border border-red-400/30 bg-red-400/10 px-5 py-3 text-sm font-semibold text-red-300">
                  {state.message}
                </p>
              )}

              <button
                type="submit"
                disabled={pending}
                className="flex w-full items-center justify-center gap-3 rounded-full bg-mint py-4.5 font-display text-base font-bold text-ink shadow-[0_10px_40px_-10px_rgba(62,240,165,0.55)] transition hover:scale-[1.01] hover:brightness-105 active:scale-95 disabled:opacity-60"
              >
                {pending ? (
                  <Loader2 size={20} className="animate-spin" />
                ) : (
                  <Sparkles size={19} />
                )}
                {pending ? "Отправляем..." : "Отправить заявку"}
              </button>

              <p className="text-center text-xs text-cream/40">
                Нажимая кнопку, вы соглашаетесь на обработку персональных данных
              </p>
            </form>
          )}
        </motion.div>
      </div>
    </section>
  );
}
