"use client";

import { Menu, Phone, Sparkles, X } from "lucide-react";
import { useEffect, useState } from "react";

const NAV = [
  { href: "#services", label: "Услуги" },
  { href: "#works", label: "Наши работы" },
  { href: "#reviews", label: "Отзывы" },
  { href: "#about", label: "О мастере" },
  { href: "#vacancies", label: "Вакансии" },
  { href: "#faq", label: "Вопросы" },
];

export function Header({ phone }: { phone: string }) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const tel = phone.replace(/[^\d+]/g, "");

  return (
    <header
      className={`fixed inset-x-0 top-0 z-40 transition-all duration-500 ${
        scrolled
          ? "border-b border-white/10 bg-ink/85 backdrop-blur-xl"
          : "bg-transparent"
      }`}
    >
      <div className="mx-auto flex h-[72px] max-w-7xl items-center justify-between px-5 lg:px-8">
        <a href="#top" className="flex items-center gap-2.5">
          <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-mint text-ink">
            <Sparkles size={20} strokeWidth={2.5} />
          </span>
          <span className="font-display text-lg font-bold tracking-tight">
            Проф<span className="text-mint">Чистка</span>
          </span>
        </a>

        <nav className="hidden items-center gap-7 lg:flex">
          {NAV.map((n) => (
            <a
              key={n.href}
              href={n.href}
              className="text-sm font-semibold text-cream/70 transition hover:text-mint"
            >
              {n.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          {phone && (
            <a
              href={`tel:${tel}`}
              className="hidden items-center gap-2 rounded-full border border-mint/40 px-5 py-2.5 text-sm font-bold text-mint transition hover:bg-mint hover:text-ink sm:flex"
            >
              <Phone size={16} />
              {phone}
            </a>
          )}
          <button
            onClick={() => setOpen((v) => !v)}
            className="flex h-11 w-11 items-center justify-center rounded-full border border-white/15 text-cream lg:hidden"
            aria-label="Меню"
          >
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Мобильное меню */}
      {open && (
        <div className="border-t border-white/10 bg-ink/95 backdrop-blur-xl lg:hidden">
          <nav className="mx-auto flex max-w-7xl flex-col gap-1 px-5 py-4">
            {NAV.map((n) => (
              <a
                key={n.href}
                href={n.href}
                onClick={() => setOpen(false)}
                className="rounded-xl px-4 py-3 text-base font-semibold text-cream/80 transition hover:bg-white/5 hover:text-mint"
              >
                {n.label}
              </a>
            ))}
            {phone && (
              <a
                href={`tel:${tel}`}
                className="mt-2 flex items-center justify-center gap-2 rounded-xl bg-mint px-4 py-3.5 font-bold text-ink"
              >
                <Phone size={18} /> {phone}
              </a>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}
