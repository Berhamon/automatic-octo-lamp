import type { Service, VacancyLink } from "@/db/schema";
import type { ReactNode } from "react";

export const inputCls =
  "w-full rounded-xl border border-ink/15 bg-white px-4 py-3 text-sm text-ink outline-none transition placeholder:text-ink/35 focus:border-mint-dim focus:ring-2 focus:ring-mint-dim/20";

export function Field({
  label,
  children,
  hint,
}: {
  label: string;
  children: ReactNode;
  hint?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-extrabold uppercase tracking-wider text-ink/55">
        {label}
      </span>
      {children}
      {hint && <span className="mt-1 block text-xs text-ink/40">{hint}</span>}
    </label>
  );
}

export function Card({
  title,
  children,
  action,
}: {
  title?: string;
  children: ReactNode;
  action?: ReactNode;
}) {
  return (
    <div className="rounded-3xl border border-ink/10 bg-white p-6 shadow-sm sm:p-8">
      {(title || action) && (
        <div className="mb-6 flex items-center justify-between gap-4">
          {title && (
            <h2 className="font-display text-lg font-bold text-ink">{title}</h2>
          )}
          {action}
        </div>
      )}
      {children}
    </div>
  );
}

/** Форма создания/редактирования карточки услуги или аренды. */
export function ServiceForm({
  service,
  action,
  submit,
}: {
  service?: Service;
  action: (formData: FormData) => void | Promise<void>;
  submit: ReactNode;
}) {
  return (
    <form action={action} className="grid gap-5">
      {service && <input type="hidden" name="id" value={service.id} />}

      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Название *">
          <input
            name="title"
            required
            defaultValue={service?.title}
            placeholder="Например: Химчистка дивана"
            className={inputCls}
          />
        </Field>
        <Field label="Цена" hint='Например: «от 2 500 ₽» или «800 ₽/сутки»'>
          <input
            name="price"
            defaultValue={service?.price}
            placeholder="от 2 500 ₽"
            className={inputCls}
          />
        </Field>
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Категория">
          <select
            name="category"
            defaultValue={service?.category ?? "service"}
            className={inputCls}
          >
            <option value="service">Услуга химчистки</option>
            <option value="rental">Аренда оборудования</option>
          </select>
        </Field>
        <Field label="Порядок сортировки" hint="Меньше — раньше в списке">
          <input
            name="sortOrder"
            type="number"
            defaultValue={service?.sortOrder ?? 0}
            className={inputCls}
          />
        </Field>
      </div>

      <Field label="Описание">
        <textarea
          name="description"
          rows={3}
          defaultValue={service?.description}
          placeholder="Короткое описание карточки"
          className={`${inputCls} resize-none`}
        />
      </Field>

      <Field label="Пункты списка" hint="Каждый пункт — с новой строки">
        <textarea
          name="features"
          rows={4}
          defaultValue={service?.features}
          placeholder={"Глубокая чистка экстрактором\nАнтибактериальная обработка\nВысыхание 6–8 часов"}
          className={`${inputCls} resize-none`}
        />
      </Field>

      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Загрузить фото" hint="jpg, png, webp — до 8 МБ">
          <input
            name="imageFile"
            type="file"
            accept="image/*"
            className={`${inputCls} file:mr-3 file:rounded-lg file:border-0 file:bg-ink file:px-3 file:py-1.5 file:text-xs file:font-bold file:text-cream`}
          />
        </Field>
        <Field label="Или ссылка на фото">
          <input
            name="imageUrl"
            type="url"
            defaultValue={service?.imageUrl ?? ""}
            placeholder="https://... или /img/hero.jpg"
            className={inputCls}
          />
        </Field>
      </div>

      {service?.imageUrl && (
        <div className="flex items-center gap-4 rounded-2xl border border-ink/10 bg-cream/60 p-4">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={service.imageUrl}
            alt=""
            className="h-16 w-24 rounded-xl object-cover"
          />
          <p className="text-xs text-ink/50">
            Текущее фото. Загрузите новое или укажите ссылку, чтобы заменить.
          </p>
        </div>
      )}

      <label className="flex w-fit cursor-pointer items-center gap-3 rounded-xl border border-ink/10 bg-cream/60 px-4 py-3">
        <input
          type="checkbox"
          name="isActive"
          defaultChecked={service?.isActive ?? true}
          className="h-4 w-4 accent-[#22c98a]"
        />
        <span className="text-sm font-bold text-ink/70">
          Показывать на сайте
        </span>
      </label>

      <div className="border-t border-ink/8 pt-6">{submit}</div>
    </form>
  );
}

/** Форма создания/редактирования вакансии. */
export function VacancyForm({
  vacancy,
  action,
  submit,
}: {
  vacancy?: VacancyLink;
  action: (formData: FormData) => void | Promise<void>;
  submit: ReactNode;
}) {
  return (
    <form action={action} className="grid gap-5">
      {vacancy && <input type="hidden" name="id" value={vacancy.id} />}

      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Название вакансии *">
          <input
            name="title"
            required
            defaultValue={vacancy?.title}
            placeholder="Мастер химчистки мебели"
            className={inputCls}
          />
        </Field>
        <Field label="Площадка" hint="Авито, hh.ru, Youla...">
          <input
            name="source"
            defaultValue={vacancy?.source}
            placeholder="Авито"
            className={inputCls}
          />
        </Field>
      </div>

      <Field label="Ссылка на вакансию *">
        <input
          name="url"
          required
          type="url"
          defaultValue={vacancy?.url}
          placeholder="https://www.avito.ru/..."
          className={inputCls}
        />
      </Field>

      <Field label="Короткое описание">
        <textarea
          name="description"
          rows={3}
          defaultValue={vacancy?.description}
          placeholder="Условия, занятость, оплата..."
          className={`${inputCls} resize-none`}
        />
      </Field>

      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Порядок сортировки">
          <input
            name="sortOrder"
            type="number"
            defaultValue={vacancy?.sortOrder ?? 0}
            className={inputCls}
          />
        </Field>
        <div className="flex items-end">
          <label className="flex w-fit cursor-pointer items-center gap-3 rounded-xl border border-ink/10 bg-cream/60 px-4 py-3">
            <input
              type="checkbox"
              name="isActive"
              defaultChecked={vacancy?.isActive ?? true}
              className="h-4 w-4 accent-[#22c98a]"
            />
            <span className="text-sm font-bold text-ink/70">
              Показывать на сайте
            </span>
          </label>
        </div>
      </div>

      <div className="border-t border-ink/8 pt-6">{submit}</div>
    </form>
  );
}
