"use client";

import { Loader2, Trash2 } from "lucide-react";
import { useFormStatus } from "react-dom";
import type { ReactNode } from "react";

/** Кнопка отправки формы с состоянием загрузки. */
export function SubmitButton({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      disabled={pending}
      className={`flex items-center justify-center gap-2 rounded-xl bg-ink px-6 py-3 text-sm font-bold text-cream transition hover:bg-mint-dim hover:text-ink disabled:opacity-60 ${className}`}
    >
      {pending && <Loader2 size={16} className="animate-spin" />}
      {children}
    </button>
  );
}

/** Кнопка удаления с подтверждением. */
export function DeleteButton({ label = "Удалить" }: { label?: string }) {
  return (
    <button
      type="submit"
      onClick={(e) => {
        if (!window.confirm("Удалить безвозвратно?")) e.preventDefault();
      }}
      className="flex items-center gap-1.5 rounded-xl border border-red-200 bg-red-50 px-4 py-2.5 text-xs font-bold text-red-600 transition hover:bg-red-100"
    >
      <Trash2 size={14} />
      {label}
    </button>
  );
}
