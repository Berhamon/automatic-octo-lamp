"use client";

import { logout } from "@/actions/auth";
import {
  BriefcaseBusiness,
  ExternalLink,
  Images,
  Inbox,
  Layers,
  LayoutDashboard,
  LogOut,
  Menu,
  Settings2,
  Sparkles,
  Star,
  UserRound,
  X,
} from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";

const NAV = [
  { href: "/admin", label: "Панель", icon: LayoutDashboard, badge: null },
  { href: "/admin/requests", label: "Заявки", icon: Inbox, badge: "new" },
  { href: "/admin/services", label: "Услуги и аренда", icon: Layers, badge: null },
  { href: "/admin/reviews", label: "Отзывы", icon: Star, badge: "pending" },
  { href: "/admin/gallery", label: "Галерея", icon: Images, badge: null },
  { href: "/admin/about", label: "О мастере", icon: UserRound, badge: null },
  { href: "/admin/vacancies", label: "Вакансии", icon: BriefcaseBusiness, badge: null },
  { href: "/admin/settings", label: "Настройки", icon: Settings2, badge: null },
] as const;

export function Sidebar({
  newRequests,
  pendingReviews,
}: {
  newRequests: number;
  pendingReviews: number;
}) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  const badgeOf = (key: string | null) =>
    key === "new" ? newRequests : key === "pending" ? pendingReviews : 0;

  const nav = (
    <>
      <div className="flex items-center gap-2.5 px-2 pb-6 pt-2">
        <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-mint text-ink">
          <Sparkles size={20} strokeWidth={2.5} />
        </span>
        <div>
          <p className="font-display text-base font-bold text-cream">
            Проф<span className="text-mint">Чистка</span>
          </p>
          <p className="text-[11px] font-semibold uppercase tracking-widest text-cream/40">
            Админ-панель
          </p>
        </div>
      </div>

      <nav className="flex-1 space-y-1 overflow-y-auto">
        {NAV.map((n) => {
          const active =
            n.href === "/admin" ? pathname === "/admin" : pathname.startsWith(n.href);
          const badge = badgeOf(n.badge);
          return (
            <Link
              key={n.href}
              href={n.href}
              onClick={() => setOpen(false)}
              className={`flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition ${
                active
                  ? "bg-mint text-ink"
                  : "text-cream/65 hover:bg-white/5 hover:text-cream"
              }`}
            >
              <n.icon size={18} />
              <span className="flex-1">{n.label}</span>
              {badge > 0 && (
                <span
                  className={`rounded-full px-2 py-0.5 text-[11px] font-extrabold ${
                    active ? "bg-ink text-mint" : "bg-mint text-ink"
                  }`}
                >
                  {badge}
                </span>
              )}
            </Link>
          );
        })}
      </nav>

      <div className="space-y-1 border-t border-white/10 pt-4">
        <Link
          href="/"
          target="_blank"
          className="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold text-cream/65 transition hover:bg-white/5 hover:text-cream"
        >
          <ExternalLink size={18} /> Открыть сайт
        </Link>
        <form action={logout}>
          <button
            type="submit"
            className="flex w-full items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold text-red-300/90 transition hover:bg-red-500/10 hover:text-red-300"
          >
            <LogOut size={18} /> Выйти
          </button>
        </form>
      </div>
    </>
  );

  return (
    <>
      {/* Мобильная шапка */}
      <div className="sticky top-0 z-40 flex items-center justify-between border-b border-ink/10 bg-white px-4 py-3 lg:hidden">
        <Link href="/admin" className="flex items-center gap-2">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-ink text-mint">
            <Sparkles size={17} />
          </span>
          <span className="font-display text-sm font-bold text-ink">Админка</span>
        </Link>
        <button
          onClick={() => setOpen(true)}
          aria-label="Меню"
          className="flex h-10 w-10 items-center justify-center rounded-xl border border-ink/15 text-ink"
        >
          <Menu size={19} />
        </button>
      </div>

      {/* Мобильный drawer */}
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-ink/60 backdrop-blur-sm"
            onClick={() => setOpen(false)}
          />
          <aside className="absolute inset-y-0 left-0 flex w-[290px] flex-col bg-pine p-4 shadow-2xl">
            <button
              onClick={() => setOpen(false)}
              aria-label="Закрыть"
              className="absolute right-4 top-4 flex h-9 w-9 items-center justify-center rounded-full border border-white/15 text-cream"
            >
              <X size={17} />
            </button>
            {nav}
          </aside>
        </div>
      )}

      {/* Десктопный сайдбар */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col bg-pine p-4 lg:flex">
        {nav}
      </aside>
    </>
  );
}
