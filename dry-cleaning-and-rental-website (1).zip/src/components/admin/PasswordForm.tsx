"use client";

import { changePassword, type AuthState } from "@/actions/auth";
import { CheckCircle2, KeyRound, Loader2 } from "lucide-react";
import { useActionState } from "react";
import { useFormStatus } from "react-dom";

const initial: AuthState = { status: "idle", message: "" };

const inputCls =
  "w-full rounded-xl border border-ink/15 bg-white px-4 py-3 text-sm text-ink outline-none transition placeholder:text-ink/35 focus:border-mint-dim focus:ring-2 focus:ring-mint-dim/20";

function Btn() {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      disabled={pending}
      className="flex items-center justify-center gap-2 rounded-xl bg-ink px-6 py-3 text-sm font-bold text-cream transition hover:bg-mint-dim hover:text-ink disabled:opacity-60"
    >
      {pending ? <Loader2 size={16} className="animate-spin" /> : <KeyRound size={16} />}
      Сменить пароль
    </button>
  );
}

export function PasswordForm() {
  const [state, action] = useActionState(changePassword, initial);

  return (
    <form action={action} className="grid gap-4">
      <label className="block">
        <span className="mb-1.5 block text-xs font-extrabold uppercase tracking-wider text-ink/55">
          Текущий пароль
        </span>
        <input
          name="current"
          type="password"
          required
          autoComplete="current-password"
          className={inputCls}
        />
      </label>
      <label className="block">
        <span className="mb-1.5 block text-xs font-extrabold uppercase tracking-wider text-ink/55">
          Новый пароль
        </span>
        <input
          name="next"
          type="password"
          required
          minLength={6}
          autoComplete="new-password"
          className={inputCls}
        />
      </label>
      <label className="block">
        <span className="mb-1.5 block text-xs font-extrabold uppercase tracking-wider text-ink/55">
          Повторите новый пароль
        </span>
        <input
          name="confirm"
          type="password"
          required
          autoComplete="new-password"
          className={inputCls}
        />
      </label>

      {state.status === "error" && (
        <p className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-600">
          {state.message}
        </p>
      )}
      {state.status === "success" && (
        <p className="flex items-center gap-2 rounded-xl border border-emerald-300 bg-emerald-50 px-4 py-3 text-sm font-semibold text-emerald-700">
          <CheckCircle2 size={16} /> {state.message}
        </p>
      )}

      <Btn />
    </form>
  );
}
