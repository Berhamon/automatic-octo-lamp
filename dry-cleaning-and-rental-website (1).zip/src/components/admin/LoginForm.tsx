"use client";

import { login, type AuthState } from "@/actions/auth";
import { Info, Loader2, Lock, LogIn, User } from "lucide-react";
import { useActionState } from "react";
import { useFormStatus } from "react-dom";

const initial: AuthState = { status: "idle", message: "" };

const inputCls =
  "w-full rounded-2xl border border-white/15 bg-white/5 py-4 pl-12 pr-5 text-cream placeholder:text-cream/35 outline-none transition focus:border-mint focus:bg-white/10";

function Btn() {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      disabled={pending}
      className="flex w-full items-center justify-center gap-2 rounded-full bg-mint py-4 font-display text-sm font-bold text-ink transition hover:brightness-110 active:scale-95 disabled:opacity-60"
    >
      {pending ? (
        <Loader2 size={18} className="animate-spin" />
      ) : (
        <LogIn size={18} />
      )}
      {pending ? "Входим..." : "Войти в панель"}
    </button>
  );
}

export function LoginForm() {
  const [state, action] = useActionState(login, initial);

  return (
    <form action={action} className="space-y-4">
      <div className="relative">
        <User
          size={18}
          className="absolute left-5 top-1/2 -translate-y-1/2 text-mint/70"
        />
        <input
          name="username"
          required
          autoComplete="username"
          placeholder="Логин"
          className={inputCls}
        />
      </div>
      <div className="relative">
        <Lock
          size={18}
          className="absolute left-5 top-1/2 -translate-y-1/2 text-mint/70"
        />
        <input
          name="password"
          type="password"
          required
          autoComplete="current-password"
          placeholder="Пароль"
          className={inputCls}
        />
      </div>

      {state.status === "error" && (
        <p className="rounded-2xl border border-red-400/30 bg-red-400/10 px-5 py-3 text-sm font-semibold text-red-300">
          {state.message}
        </p>
      )}

      <Btn />

      <p className="flex items-start gap-2 rounded-2xl bg-white/5 px-4 py-3 text-xs leading-relaxed text-cream/45">
        <Info size={14} className="mt-0.5 shrink-0 text-mint/60" />
        При первом входе используйте логин <b className="text-cream/70">admin</b> и
        пароль <b className="text-cream/70">admin123</b> — затем обязательно смените
        пароль в настройках.
      </p>
    </form>
  );
}
