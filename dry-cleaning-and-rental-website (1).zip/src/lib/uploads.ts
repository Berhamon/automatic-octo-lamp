import { randomUUID } from "crypto";
import { mkdir, writeFile } from "fs/promises";
import path from "path";

const MAX_SIZE = 8 * 1024 * 1024; // 8 МБ

const MIME_EXT: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "image/gif": "gif",
  "image/avif": "avif",
};

/**
 * Сохраняет загруженный файл в public/uploads и возвращает публичный путь.
 * Возвращает null, если файл отсутствует (поле не обязательное).
 * Бросает ошибку при неверном типе/размере.
 */
export async function saveUploadedImage(
  file: FormDataEntryValue | null
): Promise<string | null> {
  if (!file || typeof file === "string") return null;
  const f = file as File;
  if (f.size === 0) return null;
  if (!MIME_EXT[f.type]) {
    throw new Error("Допустимы только изображения (jpg, png, webp, gif, avif)");
  }
  if (f.size > MAX_SIZE) {
    throw new Error("Файл слишком большой (максимум 8 МБ)");
  }
  const ext = MIME_EXT[f.type];
  const name = `${randomUUID()}.${ext}`;
  const dir = path.join(process.cwd(), "public", "uploads");
  await mkdir(dir, { recursive: true });
  const buffer = Buffer.from(await f.arrayBuffer());
  await writeFile(path.join(dir, name), buffer);
  return `/uploads/${name}`;
}

/** Возвращает путь из загруженного файла либо из поля URL, либо fallback. */
export async function resolveImage(
  formData: FormData,
  fileField: string,
  urlField: string,
  fallback = ""
): Promise<string> {
  const uploaded = await saveUploadedImage(formData.get(fileField));
  if (uploaded) return uploaded;
  const url = (formData.get(urlField) as string | null)?.trim() ?? "";
  return url || fallback;
}
