import { db } from "@/db";
import { admins, sessions } from "@/db/schema";
import { eq, lt } from "drizzle-orm";
import { randomBytes, scryptSync, timingSafeEqual } from "crypto";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";

export const SESSION_COOKIE = "pf_session";
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 30; // 30 дней

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const candidate = scryptSync(password, salt, 64).toString("hex");
  const a = Buffer.from(hash, "utf8");
  const b = Buffer.from(candidate, "utf8");
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}

/** Создаёт администратора по умолчанию, если таблица пуста (первый запуск). */
export async function ensureDefaultAdmin(): Promise<void> {
  const rows = await db.select({ id: admins.id }).from(admins).limit(1);
  if (rows.length === 0) {
    await db.insert(admins).values({
      username: "admin",
      passwordHash: hashPassword("admin123"),
    });
  }
}

export async function createSession(): Promise<string> {
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_TTL_MS);
  await db.insert(sessions).values({ id: token, expiresAt });
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    expires: expiresAt,
  });
  return token;
}

export async function destroySession(): Promise<void> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (token) {
    await db.delete(sessions).where(eq(sessions.id, token));
  }
  store.delete(SESSION_COOKIE);
}

export async function isAuthenticated(): Promise<boolean> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return false;
  // Чистим протухшие сессии «на ходу»
  await db.delete(sessions).where(lt(sessions.expiresAt, new Date()));
  const rows = await db
    .select({ id: sessions.id })
    .from(sessions)
    .where(eq(sessions.id, token))
    .limit(1);
  return rows.length > 0;
}

/** Редиректит на логин, если администратор не авторизован. */
export async function requireAdmin(): Promise<void> {
  const ok = await isAuthenticated();
  if (!ok) redirect("/admin/login");
}
