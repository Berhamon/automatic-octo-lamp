export const REQUEST_STATUSES = [
  { value: "new", label: "Новая", cls: "bg-emerald-100 text-emerald-800 border border-emerald-200" },
  { value: "in_progress", label: "В работе", cls: "bg-amber-100 text-amber-800 border border-amber-200" },
  { value: "done", label: "Выполнена", cls: "bg-sky-100 text-sky-800 border border-sky-200" },
  { value: "rejected", label: "Отклонена", cls: "bg-zinc-200 text-zinc-600 border border-zinc-300" },
] as const;

export type RequestStatus = (typeof REQUEST_STATUSES)[number]["value"];

export function statusMeta(value: string) {
  return (
    REQUEST_STATUSES.find((s) => s.value === value) ?? {
      value: value as RequestStatus,
      label: value,
      cls: "bg-zinc-100 text-zinc-700 border border-zinc-200",
    }
  );
}

export function formatDateRu(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return new Intl.DateTimeFormat("ru-RU", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(d);
}

export function plural(n: number, forms: [string, string, string]): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return forms[0];
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return forms[1];
  return forms[2];
}

/** Превращает текст с переносами строк в список фич. */
export function linesToList(text: string): string[] {
  return text
    .split("\n")
    .map((s) => s.trim())
    .filter(Boolean);
}
