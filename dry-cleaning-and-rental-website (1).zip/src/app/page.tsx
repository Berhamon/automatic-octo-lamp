import { db } from "@/db";
import {
  aboutInfo,
  galleryItems,
  reviews,
  services,
  siteSettings,
  vacancyLinks,
} from "@/db/schema";
import { asc, desc, eq } from "drizzle-orm";
import { Header } from "@/components/site/Header";
import { Hero } from "@/components/site/Hero";
import { Marquee } from "@/components/site/Marquee";
import { Services } from "@/components/site/Services";
import { Steps } from "@/components/site/Steps";
import { Gallery } from "@/components/site/Gallery";
import { Reviews } from "@/components/site/Reviews";
import { About } from "@/components/site/About";
import { Vacancies } from "@/components/site/Vacancies";
import { Faq } from "@/components/site/Faq";
import { RequestForm } from "@/components/site/RequestForm";
import { Footer } from "@/components/site/Footer";
import { FloatingContact } from "@/components/site/FloatingContact";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [
    serviceRows,
    reviewRows,
    galleryRows,
    aboutRows,
    vacancyRows,
    settingRows,
  ] = await Promise.all([
    db
      .select()
      .from(services)
      .where(eq(services.isActive, true))
      .orderBy(asc(services.sortOrder), desc(services.id)),
    db
      .select()
      .from(reviews)
      .where(eq(reviews.isApproved, true))
      .orderBy(desc(reviews.createdAt))
      .limit(12),
    db.select().from(galleryItems).orderBy(desc(galleryItems.id)).limit(7),
    db.select().from(aboutInfo).limit(1),
    db
      .select()
      .from(vacancyLinks)
      .where(eq(vacancyLinks.isActive, true))
      .orderBy(asc(vacancyLinks.sortOrder), desc(vacancyLinks.id)),
    db.select().from(siteSettings),
  ]);

  const settings = Object.fromEntries(
    settingRows.map((s) => [s.key, s.value])
  );
  const phone = settings.phone || aboutRows[0]?.phone || "";

  return (
    <main>
      <Header phone={phone} />
      <Hero phone={phone} />
      <Marquee />
      <Services services={serviceRows} />
      <Steps />
      <Gallery items={galleryRows} />
      <Reviews reviews={reviewRows} />
      <About about={aboutRows[0] ?? null} />
      <Vacancies vacancies={vacancyRows} />
      <Faq />
      <RequestForm services={serviceRows.map((s) => s.title)} />
      <Footer settings={settings} />
      <FloatingContact
        phone={phone}
        whatsapp={settings.whatsapp ?? ""}
        telegram={settings.telegram ?? ""}
      />
    </main>
  );
}
