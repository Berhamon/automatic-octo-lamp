import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Manrope, Unbounded } from "next/font/google";
import "./globals.css";

const unbounded = Unbounded({
  subsets: ["latin", "cyrillic"],
  variable: "--font-unbounded",
  weight: ["400", "600", "700", "800"],
});

const manrope = Manrope({
  subsets: ["latin", "cyrillic"],
  variable: "--font-manrope",
  weight: ["400", "500", "600", "700", "800"],
});

export const metadata: Metadata = {
  title: "ПрофЧистка — химчистка мебели и аренда оборудования",
  description:
    "Профессиональная химчистка мебели, ковров и салонов авто с выездом на дом. Аренда оборудования для химчистки. Оставьте заявку — перезвоним за 15 минут.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru">
      <body
        className={`${unbounded.variable} ${manrope.variable} bg-ink text-cream antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
