import { db } from "@/db";
import { requests } from "@/db/schema";
import { isAuthenticated } from "@/lib/auth";
import { statusMeta } from "@/lib/format";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

function csvCell(v: string | null | undefined): string {
  return `"${(v ?? "").replace(/"/g, '""')}"`;
}

/** Экспорт всех заявок в CSV с BOM для корректного открытия в Excel. */
export async function GET() {
  if (!(await isAuthenticated())) {
    return new Response("Unauthorized", { status: 401 });
  }

  const rows = await db.select().from(requests).orderBy(desc(requests.createdAt));

  const header = ["ID", "ФИО", "Телефон", "Адрес", "Услуга", "Комментарий", "Статус", "Дата"];
  const lines = rows.map((r) =>
    [
      r.id,
      csvCell(r.fullName),
      csvCell(r.phone),
      csvCell(r.address),
      csvCell(r.serviceTitle),
      csvCell(r.comment),
      csvCell(statusMeta(r.status).label),
      new Date(r.createdAt).toLocaleString("ru-RU"),
    ].join(";")
  );

  const csv = "﻿" + [header.join(";"), ...lines].join("\r\n");

  return new Response(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": 'attachment; filename="requests.csv"',
    },
  });
}
