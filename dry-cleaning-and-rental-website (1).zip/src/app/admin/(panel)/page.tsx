import { approveReviewShortcut } from "./shortcuts";
import { db } from "@/db";
import {
  galleryItems,
  requests,
  reviews,
  services,
  vacancyLinks,
} from "@/db/schema";
import { formatDateRu, REQUEST_STATUSES, statusMeta } from "@/lib/format";
import {
  Check,
  FileSpreadsheet,
  Images,
  Inbox,
  Layers,
  LayoutDashboard,
  Plus,
  Star,
} from "lucide-react";
import Link from "next/link";
import { desc, eq, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function AdminDashboard() {
  const [byStatus, [serviceCount], [galleryCount], [vacancyCount], pendingReviews, recent] =
    await Promise.all([
      db
        .select({ status: requests.status, c: sql<number>`count(*)` })
        .from(requests)
        .groupBy(requests.status),
      db.select({ c: sql<number>`count(*)` }).from(services),
      db.select({ c: sql<number>`count(*)` }).from(galleryItems),
      db.select({ c: sql<number>`count(*)` }).from(vacancyLinks),
      db
        .select()
        .from(reviews)
        .where(eq(reviews.isApproved, false))
        .orderBy(desc(reviews.createdAt))
        .limit(3),
      db
        .select()
        .from(requests)
        .orderBy(desc(requests.createdAt))
        .limit(6),
    ]);

  const counts = Object.fromEntries(byStatus.map((r) => [r.status, Number(r.c)]));
  const total = byStatus.reduce((a, r) => a + Number(r.c), 0);

  const stats = [
    { label: "Всего заявок", value: total, icon: Inbox, href: "/admin/requests" },
    { label: "Новые заявки", value: counts.new ?? 0, icon: Inbox, href: "/admin/requests?status=new" },
    { label: "Карточек услуг", value: Number(serviceCount.c), icon: Layers, href: "/admin/services" },
    { label: "Работ в галерее", value: Number(galleryCount.c), icon: Images, href: "/admin/gallery" },
    { label: "Вакансий", value: Number(vacancyCount.c), icon: Star, href: "/admin/vacancies" },
  ];

  const maxC = Math.max(1, ...byStatus.map((r) => Number(r.c)));

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="flex items-center gap-3 font-display text-2xl font-bold">
            <LayoutDashboard className="text-mint-dim" /> Панель управления
          </h1>
          <p className="mt-1 text-sm text-ink/55">
            Обзор заявок, отзывов и контента сайта
          </p>
        </div>
        <div className="flex gap-3">
          <a
            href="/api/admin/requests.csv"
            className="flex items-center gap-2 rounded-xl border border-ink/15 bg-white px-4 py-2.5 text-sm font-bold text-ink/70 transition hover:border-mint-dim hover:text-ink"
          >
            <FileSpreadsheet size={16} /> Экспорт заявок CSV
          </a>
          <Link
            href="/admin/services/new"
            className="flex items-center gap-2 rounded-xl bg-ink px-4 py-2.5 text-sm font-bold text-cream transition hover:bg-mint-dim hover:text-ink"
          >
            <Plus size={16} /> Новая карточка
          </Link>
        </div>
      </div>

      {/* Статистика */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
        {stats.map((s) => (
          <Link
            key={s.label}
            href={s.href}
            className="rounded-3xl border border-ink/10 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
          >
            <s.icon size={20} className="text-mint-dim" />
            <p className="mt-3 font-display text-3xl font-bold">{s.value}</p>
            <p className="mt-1 text-xs font-bold uppercase tracking-wide text-ink/45">
              {s.label}
            </p>
          </Link>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        {/* Последние заявки */}
        <div className="rounded-3xl border border-ink/10 bg-white p-6 shadow-sm sm:p-7">
          <div className="mb-5 flex items-center justify-between">
            <h2 className="font-display text-lg font-bold">Последние заявки</h2>
            <Link
              href="/admin/requests"
              className="text-sm font-bold text-mint-dim hover:underline"
            >
              Все заявки →
            </Link>
          </div>
          {recent.length === 0 ? (
            <p className="py-10 text-center text-sm text-ink/45">
              Заявок пока нет — они появятся здесь
            </p>
          ) : (
            <ul className="divide-y divide-ink/8">
              {recent.map((r) => (
                <li key={r.id} className="flex items-center gap-4 py-3.5">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-ink font-display text-sm font-bold text-mint">
                    {r.fullName.slice(0, 1).toUpperCase()}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-bold">{r.fullName}</p>
                    <p className="truncate text-xs text-ink/50">
                      {r.serviceTitle || "Общая заявка"} · {formatDateRu(r.createdAt)}
                    </p>
                  </div>
                  <span
                    className={`whitespace-nowrap rounded-full px-3 py-1 text-[11px] font-extrabold ${statusMeta(r.status).cls}`}
                  >
                    {statusMeta(r.status).label}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Воронка + модерация */}
        <div className="space-y-6">
          <div className="rounded-3xl border border-ink/10 bg-white p-6 shadow-sm sm:p-7">
            <h2 className="mb-5 font-display text-lg font-bold">Воронка заявок</h2>
            <div className="space-y-3.5">
              {REQUEST_STATUSES.map((s) => {
                const c = counts[s.value] ?? 0;
                return (
                  <div key={s.value}>
                    <div className="mb-1 flex justify-between text-xs font-bold">
                      <span className="text-ink/60">{s.label}</span>
                      <span>{c}</span>
                    </div>
                    <div className="h-2.5 overflow-hidden rounded-full bg-ink/8">
                      <div
                        className={`h-full rounded-full ${
                          s.value === "new"
                            ? "bg-emerald-500"
                            : s.value === "in_progress"
                              ? "bg-amber-400"
                              : s.value === "done"
                                ? "bg-sky-500"
                                : "bg-zinc-400"
                        }`}
                        style={{ width: `${(c / maxC) * 100}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="rounded-3xl border border-ink/10 bg-white p-6 shadow-sm sm:p-7">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-display text-lg font-bold">На модерации</h2>
              <Link
                href="/admin/reviews"
                className="text-sm font-bold text-mint-dim hover:underline"
              >
                Все →
              </Link>
            </div>
            {pendingReviews.length === 0 ? (
              <p className="py-4 text-center text-sm text-ink/45">
                Новых отзывов нет
              </p>
            ) : (
              <ul className="space-y-4">
                {pendingReviews.map((r) => (
                  <li
                    key={r.id}
                    className="rounded-2xl border border-ink/10 bg-cream/60 p-4"
                  >
                    <p className="text-sm font-bold">
                      {r.name} · {"★".repeat(r.rating)}
                    </p>
                    <p className="mt-1 line-clamp-2 text-xs text-ink/60">
                      {r.text}
                    </p>
                    <form action={approveReviewShortcut} className="mt-3">
                      <input type="hidden" name="id" value={r.id} />
                      <button className="flex items-center gap-1.5 rounded-lg bg-mint-dim px-3.5 py-2 text-xs font-bold text-ink transition hover:brightness-110">
                        <Check size={14} /> Одобрить
                      </button>
                    </form>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
