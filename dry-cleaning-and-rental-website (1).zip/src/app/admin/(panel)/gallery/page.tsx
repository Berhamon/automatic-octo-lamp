import { addGalleryItem, deleteGalleryItem } from "@/actions/admin";
import { db } from "@/db";
import { galleryItems } from "@/db/schema";
import { Card, Field, inputCls } from "@/components/admin/forms";
import { DeleteButton, SubmitButton } from "@/components/admin/AdminUI";
import { Images, Plus } from "lucide-react";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function AdminGalleryPage() {
  const rows = await db.select().from(galleryItems).orderBy(desc(galleryItems.id));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="flex items-center gap-3 font-display text-2xl font-bold">
          <Images className="text-mint-dim" /> Галерея «до / после»
        </h1>
        <p className="mt-1 text-sm text-ink/55">
          Фотографии выполненных работ — на сайте показываются интерактивным
          слайдером сравнения
        </p>
      </div>

      <Card title="Добавить работу">
        <form action={addGalleryItem} className="grid gap-5">
          <div className="grid gap-5 sm:grid-cols-2">
            <Field label="Название работы *">
              <input
                name="title"
                required
                placeholder="Диван после 3 лет с детьми"
                className={inputCls}
              />
            </Field>
            <Field label="Описание">
              <input
                name="description"
                placeholder="Экстракторная чистка, 2 часа работы"
                className={inputCls}
              />
            </Field>
          </div>

          <div className="grid gap-5 sm:grid-cols-2">
            <div className="rounded-2xl border border-dashed border-ink/20 p-4">
              <p className="mb-3 text-xs font-extrabold uppercase tracking-wider text-red-500">
                Фото «ДО» *
              </p>
              <Field label="Загрузить">
                <input
                  name="beforeFile"
                  type="file"
                  accept="image/*"
                  className={`${inputCls} file:mr-3 file:rounded-lg file:border-0 file:bg-ink file:px-3 file:py-1.5 file:text-xs file:font-bold file:text-cream`}
                />
              </Field>
              <div className="mt-3">
                <Field label="Или ссылка">
                  <input
                    name="beforeUrl"
                    type="url"
                    placeholder="/img/before-sofa.jpg"
                    className={inputCls}
                  />
                </Field>
              </div>
            </div>

            <div className="rounded-2xl border border-dashed border-ink/20 p-4">
              <p className="mb-3 text-xs font-extrabold uppercase tracking-wider text-emerald-600">
                Фото «ПОСЛЕ» *
              </p>
              <Field label="Загрузить">
                <input
                  name="afterFile"
                  type="file"
                  accept="image/*"
                  className={`${inputCls} file:mr-3 file:rounded-lg file:border-0 file:bg-ink file:px-3 file:py-1.5 file:text-xs file:font-bold file:text-cream`}
                />
              </Field>
              <div className="mt-3">
                <Field label="Или ссылка">
                  <input
                    name="afterUrl"
                    type="url"
                    placeholder="/img/after-sofa.jpg"
                    className={inputCls}
                  />
                </Field>
              </div>
            </div>
          </div>

          <div className="border-t border-ink/8 pt-5">
            <SubmitButton>
              <Plus size={16} /> Добавить в галерею
            </SubmitButton>
          </div>
        </form>
      </Card>

      {rows.length === 0 ? (
        <p className="rounded-3xl border border-dashed border-ink/20 bg-white/60 p-14 text-center text-sm text-ink/45">
          В галерее пока пусто
        </p>
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {rows.map((g) => (
            <article
              key={g.id}
              className="overflow-hidden rounded-3xl border border-ink/10 bg-white shadow-sm"
            >
              <div className="grid grid-cols-2">
                <div className="relative">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={g.beforeUrl}
                    alt="до"
                    className="h-32 w-full object-cover"
                  />
                  <span className="absolute left-2 top-2 rounded-full bg-ink/80 px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-wider text-white">
                    До
                  </span>
                </div>
                <div className="relative">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={g.afterUrl}
                    alt="после"
                    className="h-32 w-full object-cover"
                  />
                  <span className="absolute right-2 top-2 rounded-full bg-mint px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-wider text-ink">
                    После
                  </span>
                </div>
              </div>
              <div className="p-4">
                <h3 className="font-display text-sm font-bold">{g.title}</h3>
                {g.description && (
                  <p className="mt-1 line-clamp-2 text-xs text-ink/50">
                    {g.description}
                  </p>
                )}
                <form action={deleteGalleryItem} className="mt-3">
                  <input type="hidden" name="id" value={g.id} />
                  <DeleteButton />
                </form>
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
