"use server";

import { db } from "@/db";
import { reviews } from "@/db/schema";
import { requireAdmin } from "@/lib/auth";
import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";

/** Быстрое одобрение отзыва с главной панели. */
export async function approveReviewShortcut(formData: FormData): Promise<void> {
  await requireAdmin();
  const id = Number(formData.get("id"));
  if (!id) return;
  await db.update(reviews).set({ isApproved: true }).where(eq(reviews.id, id));
  revalidatePath("/admin");
  revalidatePath("/admin/reviews");
  revalidatePath("/");
}
