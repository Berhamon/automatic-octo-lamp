import { saveAbout } from "@/actions/admin";
import { db } from "@/db";
import { aboutInfo } from "@/db/schema";
import { Card, Field, inputCls } from "@/components/admin/forms";
import { SubmitButton } from "@/components/admin/AdminUI";
import { CheckCircle2, Save, UserRound } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function AdminAboutPage({
  searchParams,
}: {
  searchParams: Promise<{ saved?: string }>;
}) {
  const { saved } = await searchParams;
  const rows = await db.select().from(aboutInfo).limit(1);
  const about = rows[0] ?? null;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="flex items-center gap-3 font-display text-2xl font-bold">
          <UserRound className="text-mint-dim" /> О мастере
        </h1>
        <p className="mt-1 text-sm text-ink/55">
          Блок «О себе» на сайте: фото, ФИО, описание и контактный номер
        </p>
      </div>

      {saved && (
        <p className="flex items-center gap-2 rounded-2xl border border-emerald-300 bg-emerald-50 px-5 py-3.5 text-sm font-bold text-emerald-800">
          <CheckCircle2 size={18} /> Изменения сохранены
        </p>
      )}

      <Card title="Данные блока">
        <form action={saveAbout} className="grid gap-5">
          <div className="grid gap-5 lg:grid-cols-[240px_1fr]">
            <div>
              <div className="overflow-hidden rounded-3xl border border-ink/10 bg-cream/60">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={about?.photoUrl || "/img/about.jpg"}
                  alt="Фото мастера"
                  className="aspect-[4/5] w-full object-cover"
                />
              </div>
              <div className="mt-4 grid gap-3">
                <Field label="Загрузить фото">
                  <input
                    name="photoFile"
                    type="file"
                    accept="image/*"
                    className={`${inputCls} file:mr-3 file:rounded-lg file:border-0 file:bg-ink file:px-3 file:py-1.5 file:text-xs file:font-bold file:text-cream`}
                  />
                </Field>
                <Field label="Или ссылка на фото">
                  <input
                    name="photoUrl"
                    type="url"
                    placeholder="/img/about.jpg"
                    className={inputCls}
                  />
                </Field>
              </div>
            </div>

            <div className="grid content-start gap-5">
              <div className="grid gap-5 sm:grid-cols-2">
                <Field label="ФИО *">
                  <input
                    name="fullName"
                    required
                    defaultValue={about?.fullName}
                    placeholder="Алексей Дроздов"
                    className={inputCls}
                  />
                </Field>
                <Field label="Должность / роль">
                  <input
                    name="role"
                    defaultValue={about?.role}
                    placeholder="Основатель и мастер химчистки"
                    className={inputCls}
                  />
                </Field>
              </div>

              <div className="grid gap-5 sm:grid-cols-2">
                <Field label="Контактный номер *">
                  <input
                    name="phone"
                    required
                    defaultValue={about?.phone}
                    placeholder="+7 (999) 123-45-67"
                    className={inputCls}
                  />
                </Field>
                <Field label="Лет опыта">
                  <input
                    name="yearsExperience"
                    type="number"
                    min={0}
                    defaultValue={about?.yearsExperience ?? 0}
                    className={inputCls}
                  />
                </Field>
              </div>

              <Field
                label="О себе / комментарии"
                hint="Расскажите о себе, подходе к работе, гарантиях. Переносы строк сохраняются."
              >
                <textarea
                  name="description"
                  rows={8}
                  defaultValue={about?.description}
                  placeholder="Здравствуйте! Меня зовут..."
                  className={`${inputCls} resize-y`}
                />
              </Field>

              <div className="border-t border-ink/8 pt-5">
                <SubmitButton>
                  <Save size={16} /> Сохранить блок
                </SubmitButton>
              </div>
            </div>
          </div>
        </form>
      </Card>
    </div>
  );
}
