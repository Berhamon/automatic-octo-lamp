import { saveService } from "@/actions/admin";
import { Card, ServiceForm } from "@/components/admin/forms";
import { SubmitButton } from "@/components/admin/AdminUI";
import { ArrowLeft, Plus } from "lucide-react";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default function NewServicePage() {
  return (
    <div className="space-y-6">
      <Link
        href="/admin/services"
        className="inline-flex items-center gap-2 text-sm font-bold text-ink/55 transition hover:text-ink"
      >
        <ArrowLeft size={16} /> К списку карточек
      </Link>
      <Card title="Новая карточка">
        <ServiceForm
          action={saveService}
          submit={
            <SubmitButton>
              <Plus size={16} /> Создать карточку
            </SubmitButton>
          }
        />
      </Card>
    </div>
  );
}
