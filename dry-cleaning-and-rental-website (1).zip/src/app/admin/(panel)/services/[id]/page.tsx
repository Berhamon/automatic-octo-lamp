import { saveService } from "@/actions/admin";
import { db } from "@/db";
import { services } from "@/db/schema";
import { Card, ServiceForm } from "@/components/admin/forms";
import { SubmitButton } from "@/components/admin/AdminUI";
import { ArrowLeft, Save } from "lucide-react";
import { eq } from "drizzle-orm";
import Link from "next/link";
import { notFound } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function EditServicePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const rows = await db
    .select()
    .from(services)
    .where(eq(services.id, Number(id)))
    .limit(1);
  const service = rows[0];
  if (!service) notFound();

  return (
    <div className="space-y-6">
      <Link
        href="/admin/services"
        className="inline-flex items-center gap-2 text-sm font-bold text-ink/55 transition hover:text-ink"
      >
        <ArrowLeft size={16} /> К списку карточек
      </Link>
      <Card title={`Редактирование: ${service.title}`}>
        <ServiceForm
          service={service}
          action={saveService}
          submit={
            <SubmitButton>
              <Save size={16} /> Сохранить изменения
            </SubmitButton>
          }
        />
      </Card>
    </div>
  );
}
