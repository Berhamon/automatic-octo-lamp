import { deleteService, toggleServiceActive } from "@/actions/admin";
import { db } from "@/db";
import { services } from "@/db/schema";
import { linesToList } from "@/lib/format";
import { DeleteButton } from "@/components/admin/AdminUI";
import { Eye, EyeOff, KeyRound, Layers, Pencil, Plus, Sparkles } from "lucide-react";
import Link from "next/link";
import { asc, desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function AdminServicesPage() {
  const rows = await db
    .select()
    .from(services)
    .orderBy(asc(services.category), asc(services.sortOrder), desc(services.id));

  const groups: { key: string; label: string }[] = [
    { key: "service", label: "Услуги химчистки" },
    { key: "rental", label: "Аренда оборудования" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="flex items-center gap-3 font-display text-2xl font-bold">
            <Layers className="text-mint-dim" /> Услуги и аренда
          </h1>
          <p className="mt-1 text-sm text-ink/55">
            Карточки, которые видят клиенты на сайте
          </p>
        </div>
        <Link
          href="/admin/services/new"
          className="flex items-center gap-2 rounded-xl bg-ink px-5 py-3 text-sm font-bold text-cream transition hover:bg-mint-dim hover:text-ink"
        >
          <Plus size={17} /> Добавить карточку
        </Link>
      </div>

      {groups.map((g) => {
        const items = rows.filter((r) => r.category === g.key);
        return (
          <section key={g.key}>
            <h2 className="mb-4 flex items-center gap-2 text-sm font-extrabold uppercase tracking-widest text-ink/50">
              {g.key === "service" ? (
                <Sparkles size={16} className="text-mint-dim" />
              ) : (
                <KeyRound size={16} className="text-mint-dim" />
              )}
              {g.label} · {items.length}
            </h2>

            {items.length === 0 ? (
              <p className="rounded-3xl border border-dashed border-ink/20 bg-white/60 p-10 text-center text-sm text-ink/45">
                Карточек нет — добавьте первую
              </p>
            ) : (
              <div className="grid gap-4 md:grid-cols-2">
                {items.map((s) => (
                  <article
                    key={s.id}
                    className={`rounded-3xl border bg-white p-5 shadow-sm transition ${
                      s.isActive ? "border-ink/10" : "border-ink/10 opacity-60"
                    }`}
                  >
                    <div className="flex gap-4">
                      {s.imageUrl ? (
                        /* eslint-disable-next-line @next/next/no-img-element */
                        <img
                          src={s.imageUrl}
                          alt=""
                          className="h-20 w-24 shrink-0 rounded-2xl object-cover"
                        />
                      ) : (
                        <span className="flex h-20 w-24 shrink-0 items-center justify-center rounded-2xl bg-pine text-mint">
                          {s.category === "rental" ? (
                            <KeyRound size={26} />
                          ) : (
                            <Sparkles size={26} />
                          )}
                        </span>
                      )}
                      <div className="min-w-0 flex-1">
                        <h3 className="font-display text-[15px] font-bold leading-snug">
                          {s.title}
                        </h3>
                        {s.price && (
                          <p className="mt-1 text-sm font-extrabold text-mint-dim">
                            {s.price}
                          </p>
                        )}
                        {!s.isActive && (
                          <span className="mt-1 inline-block rounded-full bg-zinc-200 px-2.5 py-0.5 text-[10px] font-extrabold uppercase tracking-wider text-zinc-500">
                            Скрыто
                          </span>
                        )}
                      </div>
                    </div>

                    {linesToList(s.features).length > 0 && (
                      <p className="mt-3 line-clamp-2 text-xs leading-relaxed text-ink/50">
                        {linesToList(s.features).join(" · ")}
                      </p>
                    )}

                    <div className="mt-4 flex flex-wrap gap-2 border-t border-ink/8 pt-4">
                      <Link
                        href={`/admin/services/${s.id}`}
                        className="flex items-center gap-1.5 rounded-xl bg-ink px-4 py-2.5 text-xs font-bold text-cream transition hover:bg-mint-dim hover:text-ink"
                      >
                        <Pencil size={13} /> Редактировать
                      </Link>
                      <form action={toggleServiceActive}>
                        <input type="hidden" name="id" value={s.id} />
                        <button className="flex items-center gap-1.5 rounded-xl border border-ink/15 px-4 py-2.5 text-xs font-bold text-ink/70 transition hover:bg-cream">
                          {s.isActive ? (
                            <>
                              <EyeOff size={13} /> Скрыть
                            </>
                          ) : (
                            <>
                              <Eye size={13} /> Показать
                            </>
                          )}
                        </button>
                      </form>
                      <form action={deleteService} className="ml-auto">
                        <input type="hidden" name="id" value={s.id} />
                        <DeleteButton />
                      </form>
                    </div>
                  </article>
                ))}
              </div>
            )}
          </section>
        );
      })}
    </div>
  );
}
