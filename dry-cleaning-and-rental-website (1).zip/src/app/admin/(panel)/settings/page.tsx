import { saveSettings } from "@/actions/admin";
import { db } from "@/db";
import { siteSettings } from "@/db/schema";
import { Card, Field, inputCls } from "@/components/admin/forms";
import { PasswordForm } from "@/components/admin/PasswordForm";
import { SubmitButton } from "@/components/admin/AdminUI";
import { CheckCircle2, Save, Settings2 } from "lucide-react";

export const dynamic = "force-dynamic";

const FIELDS: { key: string; label: string; placeholder: string; hint?: string }[] = [
  { key: "phone", label: "Телефон", placeholder: "+7 (999) 123-45-67" },
  { key: "email", label: "Email", placeholder: "clean@example.ru" },
  {
    key: "whatsapp",
    label: "Ссылка WhatsApp",
    placeholder: "https://wa.me/79991234567",
    hint: "Формат: https://wa.me/<номер без +>",
  },
  {
    key: "telegram",
    label: "Ссылка Telegram",
    placeholder: "https://t.me/username",
  },
  { key: "city", label: "Город / район работы", placeholder: "Москва и область" },
  {
    key: "workingHours",
    label: "Часы работы",
    placeholder: "Ежедневно 8:00–22:00",
  },
];

export default async function AdminSettingsPage({
  searchParams,
}: {
  searchParams: Promise<{ saved?: string }>;
}) {
  const { saved } = await searchParams;
  const rows = await db.select().from(siteSettings);
  const values = Object.fromEntries(rows.map((r) => [r.key, r.value]));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="flex items-center gap-3 font-display text-2xl font-bold">
          <Settings2 className="text-mint-dim" /> Настройки
        </h1>
        <p className="mt-1 text-sm text-ink/55">
          Контакты на сайте и доступ администратора
        </p>
      </div>

      {saved && (
        <p className="flex items-center gap-2 rounded-2xl border border-emerald-300 bg-emerald-50 px-5 py-3.5 text-sm font-bold text-emerald-800">
          <CheckCircle2 size={18} /> Настройки сохранены
        </p>
      )}

      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <Card
          title="Контакты сайта"
        >
          <form action={saveSettings} className="grid gap-5">
            <div className="grid gap-5 sm:grid-cols-2">
              {FIELDS.map((f) => (
                <Field key={f.key} label={f.label} hint={f.hint}>
                  <input
                    name={f.key}
                    defaultValue={values[f.key] ?? ""}
                    placeholder={f.placeholder}
                    className={inputCls}
                  />
                </Field>
              ))}
            </div>
            <div className="border-t border-ink/8 pt-5">
              <SubmitButton>
                <Save size={16} /> Сохранить контакты
              </SubmitButton>
            </div>
          </form>
        </Card>

        <Card title="Смена пароля администратора">
          <PasswordForm />
          <p className="mt-5 rounded-2xl bg-cream/70 px-4 py-3.5 text-xs leading-relaxed text-ink/50">
            Используйте пароль длиной от 6 символов с буквами и цифрами. После
            смены пароля текущая сессия останется активной.
          </p>
        </Card>
      </div>
    </div>
  );
}
