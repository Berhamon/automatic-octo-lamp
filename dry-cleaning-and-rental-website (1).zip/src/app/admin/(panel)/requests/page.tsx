import {
  deleteRequest,
  setRequestStatus,
} from "@/actions/admin";
import { db } from "@/db";
import { requests } from "@/db/schema";
import { statusMeta, REQUEST_STATUSES, formatDateRu } from "@/lib/format";
import { DeleteButton } from "@/components/admin/AdminUI";
import { Check, ClipboardList, Inbox, MapPin, MessageSquareText, Phone, RotateCcw, X } from "lucide-react";
import Link from "next/link";
import { desc, eq, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function AdminRequestsPage({
  searchParams,
}: {
  searchParams: Promise<{ status?: string }>;
}) {
  const { status } = await searchParams;
  const filter = REQUEST_STATUSES.some((s) => s.value === status)
    ? (status as string)
    : null;

  const [rows, counts] = await Promise.all([
    filter
      ? db
          .select()
          .from(requests)
          .where(eq(requests.status, filter))
          .orderBy(desc(requests.createdAt))
      : db.select().from(requests).orderBy(desc(requests.createdAt)),
    db
      .select({ status: requests.status, c: sql<number>`count(*)` })
      .from(requests)
      .groupBy(requests.status),
  ]);

  const countOf = (v: string) =>
    Number(counts.find((x) => x.status === v)?.c ?? 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="flex items-center gap-3 font-display text-2xl font-bold">
            <Inbox className="text-mint-dim" /> Заявки
          </h1>
          <p className="mt-1 text-sm text-ink/55">
            Принимайте, обрабатывайте и закрывайте обращения клиентов
          </p>
        </div>
        <a
          href="/api/admin/requests.csv"
          className="rounded-xl border border-ink/15 bg-white px-4 py-2.5 text-sm font-bold text-ink/70 transition hover:border-mint-dim"
        >
          Экспорт CSV
        </a>
      </div>

      {/* Фильтры */}
      <div className="flex flex-wrap gap-2">
        <Link
          href="/admin/requests"
          className={`rounded-full px-4 py-2 text-sm font-bold transition ${
            !filter
              ? "bg-ink text-cream"
              : "border border-ink/15 bg-white text-ink/60 hover:text-ink"
          }`}
        >
          Все · {counts.reduce((a, r) => a + Number(r.c), 0)}
        </Link>
        {REQUEST_STATUSES.map((s) => (
          <Link
            key={s.value}
            href={`/admin/requests?status=${s.value}`}
            className={`rounded-full px-4 py-2 text-sm font-bold transition ${
              filter === s.value
                ? "bg-ink text-cream"
                : "border border-ink/15 bg-white text-ink/60 hover:text-ink"
            }`}
          >
            {s.label} · {countOf(s.value)}
          </Link>
        ))}
      </div>

      {rows.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-ink/20 bg-white/60 p-16 text-center">
          <Inbox size={36} className="mx-auto text-ink/25" />
          <p className="mt-4 font-semibold text-ink/50">
            {filter ? "Заявок с таким статусом нет" : "Заявок пока нет"}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {rows.map((r) => (
            <article
              key={r.id}
              className="rounded-3xl border border-ink/10 bg-white p-6 shadow-sm"
            >
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="flex items-center gap-4">
                  <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-ink font-display text-lg font-bold text-mint">
                    {r.fullName.slice(0, 1).toUpperCase()}
                  </span>
                  <div>
                    <h3 className="font-display text-base font-bold">
                      {r.fullName}
                    </h3>
                    <p className="text-xs font-semibold text-ink/45">
                      #{r.id} · {formatDateRu(r.createdAt)}
                    </p>
                  </div>
                </div>
                <span
                  className={`rounded-full px-4 py-1.5 text-xs font-extrabold uppercase tracking-wide ${statusMeta(r.status).cls}`}
                >
                  {statusMeta(r.status).label}
                </span>
              </div>

              <div className="mt-5 grid gap-3 text-sm sm:grid-cols-2">
                <a
                  href={`tel:${r.phone.replace(/[^\d+]/g, "")}`}
                  className="flex items-center gap-2.5 rounded-xl bg-cream/70 px-4 py-3 font-bold text-ink/85 transition hover:bg-mint/30"
                >
                  <Phone size={16} className="text-mint-dim" /> {r.phone}
                </a>
                <p className="flex items-center gap-2.5 rounded-xl bg-cream/70 px-4 py-3 text-ink/75">
                  <MapPin size={16} className="shrink-0 text-mint-dim" />
                  {r.address}
                </p>
              </div>

              {r.serviceTitle && (
                <p className="mt-3 flex items-center gap-2.5 rounded-xl bg-ink/[0.04] px-4 py-3 text-sm font-bold text-ink/75">
                  <ClipboardList size={16} className="shrink-0 text-mint-dim" />
                  {r.serviceTitle}
                </p>
              )}

              {r.comment && (
                <p className="mt-3 flex items-start gap-2.5 rounded-xl bg-ink/[0.04] px-4 py-3 text-sm leading-relaxed text-ink/65">
                  <MessageSquareText
                    size={16}
                    className="mt-0.5 shrink-0 text-mint-dim"
                  />
                  {r.comment}
                </p>
              )}

              <div className="mt-5 flex flex-wrap gap-2 border-t border-ink/8 pt-5">
                {r.status !== "in_progress" && r.status !== "done" && (
                  <form action={setRequestStatus}>
                    <input type="hidden" name="id" value={r.id} />
                    <input type="hidden" name="status" value="in_progress" />
                    <button className="flex items-center gap-1.5 rounded-xl bg-amber-100 px-4 py-2.5 text-xs font-bold text-amber-800 transition hover:bg-amber-200">
                      <Check size={14} /> Принять в работу
                    </button>
                  </form>
                )}
                {(r.status === "in_progress" || r.status === "new") && (
                  <form action={setRequestStatus}>
                    <input type="hidden" name="id" value={r.id} />
                    <input type="hidden" name="status" value="done" />
                    <button className="flex items-center gap-1.5 rounded-xl bg-sky-100 px-4 py-2.5 text-xs font-bold text-sky-800 transition hover:bg-sky-200">
                      <Check size={14} /> Завершить
                    </button>
                  </form>
                )}
                {r.status !== "rejected" && r.status !== "done" && (
                  <form action={setRequestStatus}>
                    <input type="hidden" name="id" value={r.id} />
                    <input type="hidden" name="status" value="rejected" />
                    <button className="flex items-center gap-1.5 rounded-xl bg-zinc-100 px-4 py-2.5 text-xs font-bold text-zinc-600 transition hover:bg-zinc-200">
                      <X size={14} /> Отклонить
                    </button>
                  </form>
                )}
                {(r.status === "rejected" || r.status === "done") && (
                  <form action={setRequestStatus}>
                    <input type="hidden" name="id" value={r.id} />
                    <input type="hidden" name="status" value="new" />
                    <button className="flex items-center gap-1.5 rounded-xl bg-emerald-100 px-4 py-2.5 text-xs font-bold text-emerald-800 transition hover:bg-emerald-200">
                      <RotateCcw size={14} /> Вернуть в новые
                    </button>
                  </form>
                )}
                <form action={deleteRequest} className="ml-auto">
                  <input type="hidden" name="id" value={r.id} />
                  <DeleteButton />
                </form>
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
