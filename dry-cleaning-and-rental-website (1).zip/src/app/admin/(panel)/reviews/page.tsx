import {
  addReviewManually,
  deleteReview,
  toggleReviewApproved,
} from "@/actions/admin";
import { db } from "@/db";
import { reviews } from "@/db/schema";
import { formatDateRu } from "@/lib/format";
import { Card, Field, inputCls } from "@/components/admin/forms";
import { DeleteButton, SubmitButton } from "@/components/admin/AdminUI";
import { Check, EyeOff, Plus, Star } from "lucide-react";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

function StarsRow({ rating }: { rating: number }) {
  return (
    <span className="flex gap-0.5 text-amber-400">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          size={15}
          fill={i < rating ? "currentColor" : "none"}
          className={i < rating ? "" : "text-ink/20"}
        />
      ))}
    </span>
  );
}

export default async function AdminReviewsPage() {
  const rows = await db.select().from(reviews).orderBy(desc(reviews.createdAt));
  const pending = rows.filter((r) => !r.isApproved);
  const approved = rows.filter((r) => r.isApproved);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="flex items-center gap-3 font-display text-2xl font-bold">
          <Star className="text-mint-dim" /> Отзывы
        </h1>
        <p className="mt-1 text-sm text-ink/55">
          Модерация отзывов клиентов — на сайте видны только одобренные
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_380px]">
        <div className="space-y-6">
          {/* На модерации */}
          <Card title={`На модерации · ${pending.length}`}>
            {pending.length === 0 ? (
              <p className="py-6 text-center text-sm text-ink/45">
                Новых отзывов нет
              </p>
            ) : (
              <ul className="space-y-4">
                {pending.map((r) => (
                  <li
                    key={r.id}
                    className="rounded-2xl border border-amber-200 bg-amber-50/60 p-5"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <p className="font-bold">{r.name}</p>
                      <div className="flex items-center gap-3">
                        <StarsRow rating={r.rating} />
                        <span className="text-xs text-ink/40">
                          {formatDateRu(r.createdAt)}
                        </span>
                      </div>
                    </div>
                    <p className="mt-2 text-sm leading-relaxed text-ink/70">
                      {r.text}
                    </p>
                    <div className="mt-4 flex gap-2">
                      <form action={toggleReviewApproved}>
                        <input type="hidden" name="id" value={r.id} />
                        <button className="flex items-center gap-1.5 rounded-xl bg-mint-dim px-4 py-2.5 text-xs font-bold text-ink transition hover:brightness-110">
                          <Check size={14} /> Опубликовать
                        </button>
                      </form>
                      <form action={deleteReview}>
                        <input type="hidden" name="id" value={r.id} />
                        <DeleteButton />
                      </form>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          {/* Опубликованные */}
          <Card title={`Опубликованные · ${approved.length}`}>
            {approved.length === 0 ? (
              <p className="py-6 text-center text-sm text-ink/45">
                Опубликованных отзывов нет
              </p>
            ) : (
              <ul className="space-y-4">
                {approved.map((r) => (
                  <li
                    key={r.id}
                    className="rounded-2xl border border-ink/10 bg-cream/50 p-5"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <p className="font-bold">{r.name}</p>
                      <div className="flex items-center gap-3">
                        <StarsRow rating={r.rating} />
                        <span className="text-xs text-ink/40">
                          {formatDateRu(r.createdAt)}
                        </span>
                      </div>
                    </div>
                    <p className="mt-2 text-sm leading-relaxed text-ink/70">
                      {r.text}
                    </p>
                    <div className="mt-4 flex gap-2">
                      <form action={toggleReviewApproved}>
                        <input type="hidden" name="id" value={r.id} />
                        <button className="flex items-center gap-1.5 rounded-xl border border-ink/15 px-4 py-2.5 text-xs font-bold text-ink/70 transition hover:bg-white">
                          <EyeOff size={14} /> Скрыть с сайта
                        </button>
                      </form>
                      <form action={deleteReview}>
                        <input type="hidden" name="id" value={r.id} />
                        <DeleteButton />
                      </form>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>

        {/* Добавить вручную */}
        <Card title="Добавить отзыв вручную">
          <form action={addReviewManually} className="grid gap-4">
            <Field label="Имя клиента *">
              <input name="name" required placeholder="Ольга С." className={inputCls} />
            </Field>
            <Field label="Оценка">
              <select name="rating" defaultValue="5" className={inputCls}>
                {[5, 4, 3, 2, 1].map((n) => (
                  <option key={n} value={n}>
                    {n} ★
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Текст отзыва *">
              <textarea
                name="text"
                required
                rows={5}
                placeholder="Текст отзыва..."
                className={`${inputCls} resize-none`}
              />
            </Field>
            <SubmitButton>
              <Plus size={16} /> Опубликовать сразу
            </SubmitButton>
          </form>
        </Card>
      </div>
    </div>
  );
}
