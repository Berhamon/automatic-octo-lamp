import { db } from "@/db";
import { requests, reviews } from "@/db/schema";
import { requireAdmin } from "@/lib/auth";
import { Sidebar } from "@/components/admin/Sidebar";
import { eq, sql } from "drizzle-orm";
import type { ReactNode } from "react";

export const dynamic = "force-dynamic";

export default async function AdminPanelLayout({
  children,
}: {
  children: ReactNode;
}) {
  await requireAdmin();

  const [[newRow], [pendingRow]] = await Promise.all([
    db
      .select({ c: sql<number>`count(*)` })
      .from(requests)
      .where(eq(requests.status, "new")),
    db
      .select({ c: sql<number>`count(*)` })
      .from(reviews)
      .where(eq(reviews.isApproved, false)),
  ]);

  return (
    <div className="min-h-screen bg-[#eef2ec] font-body text-ink">
      <Sidebar
        newRequests={Number(newRow?.c ?? 0)}
        pendingReviews={Number(pendingRow?.c ?? 0)}
      />
      <div className="lg:pl-64">
        <main className="mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-8">
          {children}
        </main>
      </div>
    </div>
  );
}
