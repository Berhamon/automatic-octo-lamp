import { saveVacancy } from "@/actions/admin";
import { Card, VacancyForm } from "@/components/admin/forms";
import { SubmitButton } from "@/components/admin/AdminUI";
import { ArrowLeft, Plus } from "lucide-react";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default function NewVacancyPage() {
  return (
    <div className="space-y-6">
      <Link
        href="/admin/vacancies"
        className="inline-flex items-center gap-2 text-sm font-bold text-ink/55 transition hover:text-ink"
      >
        <ArrowLeft size={16} /> К списку вакансий
      </Link>
      <Card title="Новая вакансия">
        <VacancyForm
          action={saveVacancy}
          submit={
            <SubmitButton>
              <Plus size={16} /> Опубликовать
            </SubmitButton>
          }
        />
      </Card>
    </div>
  );
}
