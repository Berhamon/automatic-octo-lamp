import { saveVacancy } from "@/actions/admin";
import { db } from "@/db";
import { vacancyLinks } from "@/db/schema";
import { Card, VacancyForm } from "@/components/admin/forms";
import { SubmitButton } from "@/components/admin/AdminUI";
import { ArrowLeft, Save } from "lucide-react";
import { eq } from "drizzle-orm";
import Link from "next/link";
import { notFound } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function EditVacancyPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const rows = await db
    .select()
    .from(vacancyLinks)
    .where(eq(vacancyLinks.id, Number(id)))
    .limit(1);
  const vacancy = rows[0];
  if (!vacancy) notFound();

  return (
    <div className="space-y-6">
      <Link
        href="/admin/vacancies"
        className="inline-flex items-center gap-2 text-sm font-bold text-ink/55 transition hover:text-ink"
      >
        <ArrowLeft size={16} /> К списку вакансий
      </Link>
      <Card title={`Редактирование: ${vacancy.title}`}>
        <VacancyForm
          vacancy={vacancy}
          action={saveVacancy}
          submit={
            <SubmitButton>
              <Save size={16} /> Сохранить изменения
            </SubmitButton>
          }
        />
      </Card>
    </div>
  );
}
