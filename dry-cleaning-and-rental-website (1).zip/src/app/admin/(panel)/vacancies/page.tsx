import { deleteVacancy, toggleVacancyActive } from "@/actions/admin";
import { db } from "@/db";
import { vacancyLinks } from "@/db/schema";
import { DeleteButton } from "@/components/admin/AdminUI";
import {
  ArrowUpRight,
  BriefcaseBusiness,
  Eye,
  EyeOff,
  Pencil,
  Plus,
} from "lucide-react";
import Link from "next/link";
import { asc, desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function AdminVacanciesPage() {
  const rows = await db
    .select()
    .from(vacancyLinks)
    .orderBy(asc(vacancyLinks.sortOrder), desc(vacancyLinks.id));

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="flex items-center gap-3 font-display text-2xl font-bold">
            <BriefcaseBusiness className="text-mint-dim" /> Вакансии
          </h1>
          <p className="mt-1 text-sm text-ink/55">
            Ссылки на ваши объявления на Авито, hh.ru и других площадках
          </p>
        </div>
        <Link
          href="/admin/vacancies/new"
          className="flex items-center gap-2 rounded-xl bg-ink px-5 py-3 text-sm font-bold text-cream transition hover:bg-mint-dim hover:text-ink"
        >
          <Plus size={17} /> Добавить вакансию
        </Link>
      </div>

      {rows.length === 0 ? (
        <p className="rounded-3xl border border-dashed border-ink/20 bg-white/60 p-14 text-center text-sm text-ink/45">
          Вакансий нет — добавьте первую ссылку
        </p>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {rows.map((v) => (
            <article
              key={v.id}
              className={`rounded-3xl border bg-white p-6 shadow-sm ${
                v.isActive ? "border-ink/10" : "border-ink/10 opacity-60"
              }`}
            >
              <div className="flex items-start justify-between gap-4">
                <div>
                  {v.source && (
                    <span className="rounded-full bg-ink px-3 py-1 text-[10px] font-extrabold uppercase tracking-widest text-mint">
                      {v.source}
                    </span>
                  )}
                  <h3 className="mt-2.5 font-display text-base font-bold leading-snug">
                    {v.title}
                  </h3>
                </div>
                {!v.isActive && (
                  <span className="rounded-full bg-zinc-200 px-2.5 py-0.5 text-[10px] font-extrabold uppercase tracking-wider text-zinc-500">
                    Скрыто
                  </span>
                )}
              </div>
              {v.description && (
                <p className="mt-2 line-clamp-2 text-sm text-ink/55">
                  {v.description}
                </p>
              )}
              <a
                href={v.url}
                target="_blank"
                rel="noreferrer"
                className="mt-3 inline-flex items-center gap-1.5 break-all text-xs font-bold text-mint-dim hover:underline"
              >
                <ArrowUpRight size={13} /> {v.url}
              </a>

              <div className="mt-4 flex flex-wrap gap-2 border-t border-ink/8 pt-4">
                <Link
                  href={`/admin/vacancies/${v.id}`}
                  className="flex items-center gap-1.5 rounded-xl bg-ink px-4 py-2.5 text-xs font-bold text-cream transition hover:bg-mint-dim hover:text-ink"
                >
                  <Pencil size={13} /> Редактировать
                </Link>
                <form action={toggleVacancyActive}>
                  <input type="hidden" name="id" value={v.id} />
                  <button className="flex items-center gap-1.5 rounded-xl border border-ink/15 px-4 py-2.5 text-xs font-bold text-ink/70 transition hover:bg-cream">
                    {v.isActive ? (
                      <>
                        <EyeOff size={13} /> Скрыть
                      </>
                    ) : (
                      <>
                        <Eye size={13} /> Показать
                      </>
                    )}
                  </button>
                </form>
                <form action={deleteVacancy} className="ml-auto">
                  <input type="hidden" name="id" value={v.id} />
                  <DeleteButton />
                </form>
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
