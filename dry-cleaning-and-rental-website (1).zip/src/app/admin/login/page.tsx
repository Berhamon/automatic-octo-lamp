import { isAuthenticated } from "@/lib/auth";
import { LoginForm } from "@/components/admin/LoginForm";
import { ArrowLeft, Sparkles } from "lucide-react";
import Link from "next/link";
import { redirect } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function AdminLoginPage() {
  if (await isAuthenticated()) redirect("/admin");

  return (
    <div className="grain relative flex min-h-screen items-center justify-center bg-ink px-5 py-10">
      <div className="glow-mint pointer-events-none absolute left-1/2 top-1/4 h-[420px] w-[420px] -translate-x-1/2 rounded-full" />

      <div className="relative w-full max-w-md">
        <Link
          href="/"
          className="mb-6 inline-flex items-center gap-2 text-sm font-semibold text-cream/50 transition hover:text-mint"
        >
          <ArrowLeft size={16} /> Назад на сайт
        </Link>

        <div className="rounded-[2rem] border border-white/10 bg-pine/80 p-8 shadow-2xl backdrop-blur sm:p-10">
          <div className="mb-8 flex flex-col items-center text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-mint text-ink">
              <Sparkles size={26} strokeWidth={2.5} />
            </span>
            <h1 className="mt-5 font-display text-2xl font-bold text-cream">
              Админ-панель
            </h1>
            <p className="mt-2 text-sm text-cream/50">
              ПрофЧистка — управление сайтом
            </p>
          </div>

          <LoginForm />
        </div>
      </div>
    </div>
  );
}
