"use server";

import { db } from "@/db";
import {
  aboutInfo,
  galleryItems,
  requests,
  reviews,
  services,
  siteSettings,
  vacancyLinks,
} from "@/db/schema";
import { requireAdmin } from "@/lib/auth";
import { resolveImage } from "@/lib/uploads";
import { eq, sql } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

function str(formData: FormData, key: string, max = 2000): string {
  const v = formData.get(key);
  return (typeof v === "string" ? v.trim() : "").slice(0, max);
}

function num(formData: FormData, key: string): number {
  const n = Number(str(formData, key, 20));
  return Number.isFinite(n) ? Math.trunc(n) : 0;
}

function refresh(...paths: string[]) {
  for (const p of paths) revalidatePath(p);
  revalidatePath("/");
}

/* ------------------------------ УСЛУГИ ------------------------------ */

export async function saveService(formData: FormData): Promise<void> {
  await requireAdmin();
  const id = num(formData, "id");
  const title = str(formData, "title", 160);
  if (!title) throw new Error("Название обязательно");

  const imageUrl = await resolveImage(formData, "imageFile", "imageUrl");

  const values = {
    title,
    description: str(formData, "description"),
    price: str(formData, "price", 80),
    category: str(formData, "category", 20) === "rental" ? "rental" : "service",
    features: str(formData, "features"),
    isActive: formData.get("isActive") === "on",
    sortOrder: num(formData, "sortOrder"),
  };

  if (id > 0) {
    await db
      .update(services)
      .set(imageUrl ? { ...values, imageUrl } : values)
      .where(eq(services.id, id));
  } else {
    await db
      .insert(services)
      .values({ ...values, imageUrl: imageUrl || null });
  }
  refresh("/admin/services");
  redirect("/admin/services");
}

export async function deleteService(formData: FormData): Promise<void> {
  await requireAdmin();
  await db.delete(services).where(eq(services.id, num(formData, "id")));
  refresh("/admin/services");
}

export async function toggleServiceActive(formData: FormData): Promise<void> {
  await requireAdmin();
  await db
    .update(services)
    .set({ isActive: sql`NOT ${services.isActive}` })
    .where(eq(services.id, num(formData, "id")));
  refresh("/admin/services");
}

/* ------------------------------ ЗАЯВКИ ------------------------------ */

export async function setRequestStatus(formData: FormData): Promise<void> {
  await requireAdmin();
  const id = num(formData, "id");
  const status = str(formData, "status", 20);
  const allowed = ["new", "in_progress", "done", "rejected"];
  if (!allowed.includes(status)) return;
  await db.update(requests).set({ status }).where(eq(requests.id, id));
  refresh("/admin/requests", "/admin");
}

export async function deleteRequest(formData: FormData): Promise<void> {
  await requireAdmin();
  await db.delete(requests).where(eq(requests.id, num(formData, "id")));
  refresh("/admin/requests", "/admin");
}

/* ------------------------------ ОТЗЫВЫ ------------------------------ */

export async function toggleReviewApproved(formData: FormData): Promise<void> {
  await requireAdmin();
  await db
    .update(reviews)
    .set({ isApproved: sql`NOT ${reviews.isApproved}` })
    .where(eq(reviews.id, num(formData, "id")));
  refresh("/admin/reviews");
}

export async function deleteReview(formData: FormData): Promise<void> {
  await requireAdmin();
  await db.delete(reviews).where(eq(reviews.id, num(formData, "id")));
  refresh("/admin/reviews");
}

export async function addReviewManually(formData: FormData): Promise<void> {
  await requireAdmin();
  const name = str(formData, "name", 80);
  const text = str(formData, "text", 1500);
  if (!name || !text) return;
  const rating = Math.min(5, Math.max(1, num(formData, "rating") || 5));
  await db.insert(reviews).values({ name, text, rating, isApproved: true });
  refresh("/admin/reviews");
  redirect("/admin/reviews");
}

/* ----------------------------- ГАЛЕРЕЯ ------------------------------ */

export async function addGalleryItem(formData: FormData): Promise<void> {
  await requireAdmin();
  const title = str(formData, "title", 160);
  const beforeUrl = await resolveImage(formData, "beforeFile", "beforeUrl");
  const afterUrl = await resolveImage(formData, "afterFile", "afterUrl");
  if (!title || !beforeUrl || !afterUrl) {
    throw new Error("Заполните название и оба фото («до» и «после»)");
  }
  await db.insert(galleryItems).values({
    title,
    description: str(formData, "description"),
    beforeUrl,
    afterUrl,
  });
  refresh("/admin/gallery");
  redirect("/admin/gallery");
}

export async function deleteGalleryItem(formData: FormData): Promise<void> {
  await requireAdmin();
  await db.delete(galleryItems).where(eq(galleryItems.id, num(formData, "id")));
  refresh("/admin/gallery");
}

/* ------------------------------ О СЕБЕ ------------------------------ */

export async function saveAbout(formData: FormData): Promise<void> {
  await requireAdmin();
  const photoUrl = await resolveImage(formData, "photoFile", "photoUrl");
  const rows = await db.select({ id: aboutInfo.id }).from(aboutInfo).limit(1);

  const values = {
    fullName: str(formData, "fullName", 160),
    role: str(formData, "role", 160),
    description: str(formData, "description"),
    phone: str(formData, "phone", 60),
    yearsExperience: num(formData, "yearsExperience"),
    ...(photoUrl ? { photoUrl } : {}),
  };

  if (rows.length === 0) {
    await db
      .insert(aboutInfo)
      .values({ ...values, photoUrl: photoUrl || "" });
  } else {
    await db.update(aboutInfo).set(values).where(eq(aboutInfo.id, rows[0].id));
  }
  refresh("/admin/about");
  redirect("/admin/about?saved=1");
}

/* ----------------------------- ВАКАНСИИ ------------------------------ */

export async function saveVacancy(formData: FormData): Promise<void> {
  await requireAdmin();
  const id = num(formData, "id");
  const title = str(formData, "title", 160);
  const url = str(formData, "url", 500);
  if (!title || !url) throw new Error("Название и ссылка обязательны");

  const values = {
    title,
    url,
    source: str(formData, "source", 80),
    description: str(formData, "description", 500),
    isActive: formData.get("isActive") === "on",
    sortOrder: num(formData, "sortOrder"),
  };

  if (id > 0) {
    await db.update(vacancyLinks).set(values).where(eq(vacancyLinks.id, id));
  } else {
    await db.insert(vacancyLinks).values(values);
  }
  refresh("/admin/vacancies");
  redirect("/admin/vacancies");
}

export async function deleteVacancy(formData: FormData): Promise<void> {
  await requireAdmin();
  await db.delete(vacancyLinks).where(eq(vacancyLinks.id, num(formData, "id")));
  refresh("/admin/vacancies");
}

export async function toggleVacancyActive(formData: FormData): Promise<void> {
  await requireAdmin();
  await db
    .update(vacancyLinks)
    .set({ isActive: sql`NOT ${vacancyLinks.isActive}` })
    .where(eq(vacancyLinks.id, num(formData, "id")));
  refresh("/admin/vacancies");
}

/* ----------------------------- НАСТРОЙКИ ----------------------------- */

const SETTING_KEYS = [
  "phone",
  "email",
  "whatsapp",
  "telegram",
  "city",
  "workingHours",
] as const;

export async function saveSettings(formData: FormData): Promise<void> {
  await requireAdmin();
  for (const key of SETTING_KEYS) {
    const value = str(formData, key, 300);
    await db
      .insert(siteSettings)
      .values({ key, value })
      .onConflictDoUpdate({ target: siteSettings.key, set: { value } });
  }
  refresh("/", "/admin/settings");
  redirect("/admin/settings?saved=1");
}


