"use server";

import { db } from "@/db";
import { requests, reviews } from "@/db/schema";
import { revalidatePath } from "next/cache";

export type FormState = {
  status: "idle" | "success" | "error";
  message: string;
};

const IDLE: FormState = { status: "idle", message: "" };

function str(formData: FormData, key: string): string {
  const v = formData.get(key);
  return typeof v === "string" ? v.trim() : "";
}

/** Публичная заявка (ФИО, телефон, адрес, комментарий, услуга). */
export async function createRequest(
  _prev: FormState,
  formData: FormData
): Promise<FormState> {
  // Honeypot — боты заполнят скрытое поле
  if (str(formData, "company")) return IDLE;

  const fullName = str(formData, "fullName");
  const phone = str(formData, "phone");
  const address = str(formData, "address");
  const comment = str(formData, "comment").slice(0, 2000);
  const serviceTitle = str(formData, "service").slice(0, 200);

  if (fullName.length < 2) {
    return { status: "error", message: "Укажите ваше ФИО" };
  }
  const digits = phone.replace(/\D/g, "");
  if (digits.length < 10 || digits.length > 15) {
    return { status: "error", message: "Укажите корректный номер телефона" };
  }
  if (address.length < 4) {
    return { status: "error", message: "Укажите адрес" };
  }

  await db.insert(requests).values({
    fullName: fullName.slice(0, 120),
    phone: phone.slice(0, 40),
    address: address.slice(0, 300),
    comment,
    serviceTitle,
    status: "new",
  });

  revalidatePath("/admin");
  return {
    status: "success",
    message: "Заявка отправлена! Перезвоним в течение 15 минут.",
  };
}

/** Публичный отзыв — отправляется на модерацию. */
export async function createReview(
  _prev: FormState,
  formData: FormData
): Promise<FormState> {
  if (str(formData, "company")) return IDLE;

  const name = str(formData, "name");
  const text = str(formData, "text");
  const ratingRaw = Number(str(formData, "rating") || "5");
  const rating = Math.min(5, Math.max(1, Math.round(ratingRaw)));

  if (name.length < 2) {
    return { status: "error", message: "Представьтесь, пожалуйста" };
  }
  if (text.length < 10) {
    return { status: "error", message: "Отзыв слишком короткий (минимум 10 символов)" };
  }

  await db.insert(reviews).values({
    name: name.slice(0, 80),
    text: text.slice(0, 1500),
    rating,
    isApproved: false,
  });

  revalidatePath("/admin");
  return {
    status: "success",
    message: "Спасибо! Отзыв появится на сайте после модерации.",
  };
}
