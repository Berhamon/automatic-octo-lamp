"use server";

import { db } from "@/db";
import { admins } from "@/db/schema";
import {
  createSession,
  destroySession,
  ensureDefaultAdmin,
  hashPassword,
  requireAdmin,
  verifyPassword,
} from "@/lib/auth";
import { eq, ilike } from "drizzle-orm";
import { redirect } from "next/navigation";

export type AuthState = { status: "idle" | "error" | "success"; message: string };

export async function login(
  _prev: AuthState,
  formData: FormData
): Promise<AuthState> {
  const username = ((formData.get("username") as string) ?? "")
    .trim()
    .toLowerCase();
  const password = ((formData.get("password") as string) ?? "").trim();

  await ensureDefaultAdmin();

  // Регистронезависимый поиск: защита от автокапитализации на телефонах
  const rows = await db
    .select()
    .from(admins)
    .where(ilike(admins.username, username))
    .limit(1);

  const admin = rows[0];
  const verified = admin ? verifyPassword(password, admin.passwordHash) : false;

  if (!admin || !verified) {
    return { status: "error", message: "Неверный логин или пароль" };
  }

  await createSession();
  redirect("/admin");
}

export async function logout(): Promise<void> {
  await destroySession();
  redirect("/admin/login");
}

export async function changePassword(
  _prev: AuthState,
  formData: FormData
): Promise<AuthState> {
  await requireAdmin();

  const current = (formData.get("current") as string) ?? "";
  const next = (formData.get("next") as string) ?? "";
  const confirm = (formData.get("confirm") as string) ?? "";

  if (next.length < 6) {
    return { status: "error", message: "Новый пароль — минимум 6 символов" };
  }
  if (next !== confirm) {
    return { status: "error", message: "Новые пароли не совпадают" };
  }

  const rows = await db.select().from(admins).limit(1);
  const admin = rows[0];
  if (!admin || !verifyPassword(current, admin.passwordHash)) {
    return { status: "error", message: "Текущий пароль указан неверно" };
  }

  await db
    .update(admins)
    .set({ passwordHash: hashPassword(next) })
    .where(eq(admins.id, admin.id));

  return { status: "success", message: "Пароль успешно обновлён" };
}
