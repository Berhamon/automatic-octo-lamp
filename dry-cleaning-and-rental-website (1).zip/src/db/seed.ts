import "dotenv/config";
import { db } from "./index";
import {
  aboutInfo,
  admins,
  galleryItems,
  requests,
  reviews,
  services,
  siteSettings,
  vacancyLinks,
} from "./schema";
import { hashPassword } from "@/lib/auth";

async function main() {
  console.log("Сидирование базы данных...");

  // --- Админ ---
  const existingAdmins = await db.select().from(admins).limit(1);
  if (existingAdmins.length === 0) {
    await db.insert(admins).values({
      username: "admin",
      passwordHash: hashPassword("admin123"),
    });
    console.log("✓ Администратор: admin / admin123");
  }

  // --- Очистка демо-контента ---
  await db.delete(requests);
  await db.delete(reviews);
  await db.delete(services);
  await db.delete(galleryItems);
  await db.delete(vacancyLinks);
  await db.delete(aboutInfo);
  await db.delete(siteSettings);

  // --- Услуги и аренда ---
  await db.insert(services).values([
    {
      title: "Химчистка дивана",
      description:
        "Глубокая экстракторная чистка тканевой и кожаной обивки дивана любой конфигурации.",
      price: "от 2 500 ₽",
      category: "service",
      imageUrl: "/img/action.jpg",
      features:
        "Предварительная обработка пятен\nЭкстракторная чистка глубоких загрязнений\nАнтибактериальная обработка\nВысыхание 6–8 часов",
      sortOrder: 1,
    },
    {
      title: "Химчистка ковра",
      description:
        "Чистка ковров любого размера и состава — шерсть, синтетика, шёлк. Выезд или забор ковра.",
      price: "от 300 ₽/м²",
      category: "service",
      imageUrl: "/img/after-carpet.jpg",
      features:
        "Удаление пятен и запахов\nВосстановление ворса\nАнтистатическая обработка\nСушка за 4–6 часов",
      sortOrder: 2,
    },
    {
      title: "Химчистка матраса",
      description:
        "Двухсторонняя чистка матраса: пятна, запахи, пылевые клещи. Гигиена здорового сна.",
      price: "от 2 000 ₽",
      category: "service",
      imageUrl: "/img/after-sofa.jpg",
      features:
        "Удаление пятен и жёлтых следов\nОбработка от пылевых клещей\nДезодорация\nБезопасно для аллергиков",
      sortOrder: 3,
    },
    {
      title: "Химчистка кресел и стульев",
      description:
        "Офисные и домашние кресла, стулья, пуфики. Скидка от 5 предметов.",
      price: "от 800 ₽",
      category: "service",
      imageUrl: "/img/after-chair.jpg",
      features:
        "Любые ткани и экокожа\nПодлокотники и подголовники\nБыстрая сушка\nСкидки за объём",
      sortOrder: 4,
    },
    {
      title: "Химчистка салона авто",
      description:
        "Комплексная чистка салона автомобиля: сиденья, пол, потолок, стойки и багажник.",
      price: "от 5 000 ₽",
      category: "service",
      imageUrl: "/img/hero.jpg",
      features:
        "Чистка на вашей территории\nУдаление сложных пятен\nКондиционер для кожи\nГотовность за 3–5 часов",
      sortOrder: 5,
    },
    {
      title: "Экстрактор Karcher Puzzi 10/1",
      description:
        "Профессиональный моющий пылесос для чистки мебели и ковров. В комплекте насадки и бак.",
      price: "1 500 ₽/сутки",
      category: "rental",
      imageUrl: "/img/equipment.jpg",
      features:
        "Насадки для мебели и пола в комплекте\nОбучение и инструкция при выдаче\nДоставка по городу от 300 ₽\nЗалог — паспорт или 10 000 ₽",
      sortOrder: 10,
    },
    {
      title: "Пароочиститель Karcher SC 5",
      description:
        "Мощный пароочиститель для точечной обработки пятен, швов и труднодоступных мест.",
      price: "900 ₽/сутки",
      category: "rental",
      imageUrl: "/img/equipment.jpg",
      features:
        "Давление пара 4.2 бар\nНабор из 6 насадок\nДезинфекция без химии\nИдеален для кухни и санузла",
      sortOrder: 11,
    },
    {
      title: "Химия и расходники",
      description:
        "Профессиональные средства в разлив: шампуни, пятновыводители, дезодоранты.",
      price: "от 250 ₽",
      category: "rental",
      imageUrl: null,
      features:
        "Шампунь для экстрактора 1 л — 350 ₽\nПятновыводитель 0.5 л — 250 ₽\nДезодорант 1 л — 300 ₽\nКонсультация по подбору бесплатно",
      sortOrder: 12,
    },
  ]);
  console.log("✓ Услуги и аренда");

  // --- Галерея ---
  await db.insert(galleryItems).values([
    {
      title: "Диван после 6 лет без чистки",
      description: "Экстракторная чистка + обработка пятен, 2.5 часа работы.",
      beforeUrl: "/img/before-sofa.jpg",
      afterUrl: "/img/after-sofa.jpg",
    },
    {
      title: "Офисное кресло переговорной",
      description: "Комплекс из 12 кресел, чистка по открытой цене за предмет.",
      beforeUrl: "/img/before-chair.jpg",
      afterUrl: "/img/after-chair.jpg",
    },
    {
      title: "Шерстяной ковёр 8 м²",
      description: "Деликатная чистка шерсти, восстановление оттенка ворса.",
      beforeUrl: "/img/before-carpet.jpg",
      afterUrl: "/img/after-carpet.jpg",
    },
  ]);
  console.log("✓ Галерея");

  // --- Отзывы ---
  await db.insert(reviews).values([
    {
      name: "Ольга Смирнова",
      text: "Думала, диван придётся выбрасывать — двое детей и кот сделали своё дело. Алексей приехал в тот же день, за 3 часа диван стал как из магазина. Пятна от сока исчезли полностью!",
      rating: 5,
      isApproved: true,
    },
    {
      name: "Дмитрий К.",
      text: "Брал экстрактор в аренду на выходные. Всё объяснили, дали инструкцию и химию. Почистил два дивана и ковры сам — сэкономил в два раза. Аппарат мощный, справился даже я-новичок.",
      rating: 5,
      isApproved: true,
    },
    {
      name: "Марина Ветрова",
      text: "Заказывала чистку двух матрасов и детского кресла. Очень аккуратный мастер, пришёл со своими бахилами, постелил плёнку. Запах потеть перестал уже к вечеру. Рекомендую!",
      rating: 5,
      isApproved: true,
    },
    {
      name: "Игорь Палыч",
      text: "Чистили салон машины после разлитого кофе. Справились на 95%, старое пятно на потолке осталось чуть заметным, но мастер предупредил об этом заранее. Честный подход — зачёт.",
      rating: 4,
      isApproved: true,
    },
    {
      name: "Аноним",
      text: "Отличный сервис, всё быстро и качественно!",
      rating: 5,
      isApproved: false,
    },
  ]);
  console.log("✓ Отзывы");

  // --- О мастере ---
  await db.insert(aboutInfo).values({
    fullName: "Алексей Дроздов",
    role: "Основатель и мастер химчистки",
    description:
      "Здравствуйте! Я занимаюсь профессиональной химчисткой с 2018 года. За это время вернул к жизни больше 500 диванов, ковров и матрасов — и ни разу не слышал «нужно было сразу выбросить».\n\nРаботаю на профессиональном оборудовании Karcher и сертифицированной химии, безопасной для детей, животных и аллергиков. Перед началом всегда честно оцениваю перспективы чистки и фиксирую цену — никаких сюрпризов в конце.\n\nКроме самой чистки, сдаю оборудование в аренду для тех, кто хочет справиться самостоятельно: покажу, расскажу и подберу химию под задачу.",
    phone: "+7 (999) 123-45-67",
    photoUrl: "/img/about.jpg",
    yearsExperience: 7,
  });
  console.log("✓ Блок «О мастере»");

  // --- Вакансии ---
  await db.insert(vacancyLinks).values([
    {
      title: "Мастер химчистки мебели",
      source: "Авито",
      url: "https://www.avito.ru/moskva/vakansii?q=%D0%BC%D0%B0%D1%81%D1%82%D0%B5%D1%80+%D1%85%D0%B8%D0%BC%D1%87%D0%B8%D1%81%D1%82%D0%BA%D0%B8",
      description:
        "Выезды по городу, оборудование предоставляем. Опыт приветствуется, научим. Доход от 60 000 ₽.",
      sortOrder: 1,
    },
    {
      title: "Помощник мастера химчистки",
      source: "hh.ru",
      url: "https://hh.ru/search/vacancy?text=%D0%BF%D0%BE%D0%BC%D0%BE%D1%89%D0%BD%D0%B8%D0%BA+%D1%85%D0%B8%D0%BC%D1%87%D0%B8%D1%81%D1%82%D0%BA%D0%B0",
      description:
        "Без опыта, стажировка за наш счёт. Гибкий график, оплата 2 раза в месяц.",
      sortOrder: 2,
    },
    {
      title: "Менеджер по работе с клиентами (удалённо)",
      source: "Авито",
      url: "https://www.avito.ru/moskva/vakansii?q=%D0%BC%D0%B5%D0%BD%D0%B5%D0%B4%D0%B6%D0%B5%D1%80+%D1%83%D0%B4%D0%B0%D0%BB%D1%91%D0%BD%D0%BD%D0%BE",
      description:
        "Приём заявок, консультации, расписание мастеров. Удалённо, 4–6 часов в день.",
      sortOrder: 3,
    },
  ]);
  console.log("✓ Вакансии");

  // --- Демо-заявки ---
  await db.insert(requests).values([
    {
      fullName: "Екатерина Лебедева",
      phone: "+7 (916) 555-23-41",
      address: "ул. Пушкина, д. 12, кв. 34",
      comment: "Диван 3-местный + ковёр 4 м². Кот оставил пару сюрпризов, нужна дезинфекция. Удобно после 18:00.",
      serviceTitle: "Химчистка дивана",
      status: "new",
    },
    {
      fullName: "Сергей Николаевич",
      phone: "+7 (903) 118-90-77",
      address: "пр. Мира, 45, офис 210",
      comment: "Хочу взять экстрактор в аренду на выходные, посоветуйте химию для шерстяного ковра.",
      serviceTitle: "Экстрактор Karcher Puzzi 10/1",
      status: "in_progress",
    },
  ]);
  console.log("✓ Демо-заявки");

  // --- Настройки сайта ---
  await db.insert(siteSettings).values([
    { key: "phone", value: "+7 (999) 123-45-67" },
    { key: "email", value: "zakaz@profchistka.ru" },
    { key: "whatsapp", value: "https://wa.me/79991234567" },
    { key: "telegram", value: "https://t.me/profchistka" },
    { key: "city", value: "Москва и Московская область" },
    { key: "workingHours", value: "Ежедневно 8:00–22:00" },
  ]);
  console.log("✓ Настройки");

  console.log("Готово!");
  process.exit(0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
