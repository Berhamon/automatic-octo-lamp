import {
  boolean,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

/** Администраторы панели управления */
export const admins = pgTable("admins", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  createdAt: timestamp("created_at", { withTimezone: false })
    .defaultNow()
    .notNull(),
});

/** Сессии администратора */
export const sessions = pgTable("sessions", {
  id: text("id").primaryKey(), // token
  createdAt: timestamp("created_at", { withTimezone: false })
    .defaultNow()
    .notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: false }).notNull(),
});

/** Карточки услуг и оборудования для аренды */
export const services = pgTable("services", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  price: text("price").notNull().default(""),
  category: text("category").notNull().default("service"), // service | rental
  imageUrl: text("image_url"),
  features: text("features").notNull().default(""), // по строке на пункт
  isActive: boolean("is_active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: false })
    .defaultNow()
    .notNull(),
});

/** Заявки с сайта */
export const requests = pgTable("requests", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  phone: text("phone").notNull(),
  address: text("address").notNull(),
  comment: text("comment").notNull().default(""),
  serviceTitle: text("service_title").notNull().default(""),
  status: text("status").notNull().default("new"), // new | in_progress | done | rejected
  createdAt: timestamp("created_at", { withTimezone: false })
    .defaultNow()
    .notNull(),
});

/** Отзывы клиентов */
export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  text: text("text").notNull(),
  rating: integer("rating").notNull().default(5),
  isApproved: boolean("is_approved").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: false })
    .defaultNow()
    .notNull(),
});

/** Галерея работ «до / после» */
export const galleryItems = pgTable("gallery_items", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  beforeUrl: text("before_url").notNull(),
  afterUrl: text("after_url").notNull(),
  createdAt: timestamp("created_at", { withTimezone: false })
    .defaultNow()
    .notNull(),
});

/** Блок «О себе» — одиночная запись */
export const aboutInfo = pgTable("about_info", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull().default(""),
  role: text("role").notNull().default(""),
  description: text("description").notNull().default(""),
  phone: text("phone").notNull().default(""),
  photoUrl: text("photo_url").notNull().default(""),
  yearsExperience: integer("years_experience").notNull().default(0),
});

/** Ссылки на вакансии (Авито, hh.ru и т.д.) */
export const vacancyLinks = pgTable("vacancy_links", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  source: text("source").notNull().default(""), // Авито, hh.ru, ...
  url: text("url").notNull(),
  description: text("description").notNull().default(""),
  isActive: boolean("is_active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
});

/** Настройки сайта (ключ-значение) */
export const siteSettings = pgTable("site_settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull().default(""),
});

export type Service = typeof services.$inferSelect;
export type Request = typeof requests.$inferSelect;
export type Review = typeof reviews.$inferSelect;
export type GalleryItem = typeof galleryItems.$inferSelect;
export type AboutInfo = typeof aboutInfo.$inferSelect;
export type VacancyLink = typeof vacancyLinks.$inferSelect;
